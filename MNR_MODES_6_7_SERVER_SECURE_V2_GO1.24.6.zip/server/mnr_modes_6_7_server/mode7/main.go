package main

import (
	"bytes"
	"crypto/rand"
	"encoding/base64"
	"encoding/binary"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"log"
	"net"
	"net/http"
	"os"
	"os/exec"
	"strings"
	"sync"
	"syscall"
	"time"
	"unsafe"
)

const (
	listenAddr = ":19302"
	adminAddr  = "127.0.0.1:8081"
	authorizeURL = "http://127.0.0.1:8080/api/internal/mode7-authorize"

	tunName = "tun200"
	tunCIDR = "10.8.0.1/24"
	vpnNet  = "10.8.0.0/24"

	handshakePrefix = "UDP_HANDSHAKE___"

	// 10.8.0.2 ... 10.8.0.254
	firstClient = 2
	lastClient  = 254

	mtu = 1420
)

var secureKeepalivePayload = []byte("MNR_KEEPALIVE_V2")

type HandshakeRequest struct {
	Mode     string `json:"mode"`
	Protocol string `json:"protocol"`
	SID      string `json:"sid"`
	HWID     string `json:"hwid"`
	Root     bool   `json:"root"`
	Tag      string `json:"tag"`
	Msg      string `json:"msg"`
	MTU      int    `json:"mtu"`
}

type HandshakeResponse struct {
	SID   string `json:"sid,omitempty"`
	IP    string `json:"ip,omitempty"`
	Error string `json:"error,omitempty"`
}

type SecureHandshake struct {
	Version int `json:"v"`
	ClientKey string `json:"client_key,omitempty"`
	Data string `json:"data"`
}

type AuthorizeResponse struct {
	Allowed bool   `json:"allowed"`
	Status  string `json:"status"`
}

type Session struct {
	SID       string
	ClientSID string
	HWID      string
	Tag       string
	Root      bool
	Crypto    *tunnelCrypto

	VPNIP      net.IP
	ClientAddr *net.UDPAddr

	CreatedAt time.Time
	LastSeen  time.Time

	Upload   uint64
	Download uint64
}

type AdminSessionView struct {
	HWID          string    `json:"hwid"`
	Mode          int       `json:"mode"`
	Protocol      string    `json:"protocol"`
	Connected     bool      `json:"connected"`
	IP            string    `json:"ip"`
	SID           string    `json:"sid"`
	ClientSID     string    `json:"client_sid,omitempty"`
	ClientAddress string    `json:"client_address,omitempty"`
	Tag           string    `json:"tag,omitempty"`
	Root          bool      `json:"root"`
	CreatedAt     time.Time `json:"created_at"`
	LastSeen      time.Time `json:"last_seen"`
	UploadBytes   uint64    `json:"upload_bytes"`
	DownloadBytes uint64    `json:"download_bytes"`
	TotalBytes    uint64    `json:"total_bytes"`
}

var (
	sessionsMu sync.RWMutex
	wanIf      string

	// server SID -> session
	sessionsBySID = make(map[string]*Session)

	// VPN IPv4 string -> session
	sessionsByIP = make(map[string]*Session)

	nextIP = firstClient
	authorizeHTTPClient = &http.Client{Timeout: 1500 * time.Millisecond}
)

const (
	iffTun    = 0x0001
	iffNoPI   = 0x1000
	tunsetIFF = 0x400454ca
)

type ifreq struct {
	Name  [16]byte
	Flags uint16
	Pad   [22]byte
}

func main() {
	log.SetFlags(log.LstdFlags | log.Lmicroseconds)
	if err := loadServerIdentity(); err != nil { log.Fatalf("crypto identity: %v", err) }
	var err error
	wanIf, err = detectWANInterface()
	if err != nil { log.Fatalf("detect WAN interface: %v", err) }
	log.Printf("🌍 WAN interface: %s", wanIf)

	log.Println("🚀 Starting STUN-UDP Mode 7 Server")
	log.Printf("🌐 UDP listening target: %s", listenAddr)
	log.Printf("🧩 TUN: %s | VPN=%s | MTU=%d", tunName, vpnNet, mtu)

	if err := setupForwardingAndNAT(); err != nil {
		log.Fatalf("❌ network setup failed: %v", err)
	}

	tun, err := createTun(tunName)
	if err != nil {
		log.Fatalf("❌ create TUN: %v", err)
	}
	defer tun.Close()

	if err := configureTun(); err != nil {
		log.Fatalf("❌ configure TUN: %v", err)
	}

	addr, err := net.ResolveUDPAddr("udp4", listenAddr)
	if err != nil {
		log.Fatalf("❌ ResolveUDPAddr: %v", err)
	}

	conn, err := net.ListenUDP("udp4", addr)
	if err != nil {
		log.Fatalf("❌ ListenUDP: %v", err)
	}
	defer conn.Close()

	// Large socket buffers help prevent drops under load.
	_ = conn.SetReadBuffer(4 * 1024 * 1024)
	_ = conn.SetWriteBuffer(4 * 1024 * 1024)

	log.Printf("✅ Mode 7 UDP listening on %s", listenAddr)
	log.Printf("✅ %s configured as %s", tunName, tunCIDR)
	log.Printf("✅ forwarding/NAT enabled only for %s", vpnNet)

	go tunReader(tun, conn)
	go sessionCleaner()
	go startAdminServer()

	udpLoop(conn, tun)
}

func adminSessionsSnapshot() []AdminSessionView {
	now := time.Now()

	sessionsMu.RLock()
	out := make([]AdminSessionView, 0, len(sessionsBySID))
	for _, s := range sessionsBySID {
		if s == nil {
			continue
		}

		clientAddress := ""
		if s.ClientAddr != nil {
			clientAddress = s.ClientAddr.String()
		}

		out = append(out, AdminSessionView{
			HWID:          strings.ToLower(strings.TrimSpace(s.HWID)),
			Mode:          7,
			Protocol:      "STUN-UDP",
			Connected:     now.Sub(s.LastSeen) <= 60*time.Second,
			IP:            s.VPNIP.String(),
			SID:           s.SID,
			ClientSID:     s.ClientSID,
			ClientAddress: clientAddress,
			Tag:           s.Tag,
			Root:          s.Root,
			CreatedAt:     s.CreatedAt,
			LastSeen:      s.LastSeen,
			UploadBytes:   s.Upload,
			DownloadBytes: s.Download,
			TotalBytes:    s.Upload + s.Download,
		})
	}
	sessionsMu.RUnlock()

	return out
}

func adminSessionsJSON(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodGet {
		http.Error(w, "GET required", http.StatusMethodNotAllowed)
		return
	}

	w.Header().Set("Content-Type", "application/json; charset=utf-8")
	w.Header().Set("Cache-Control", "no-store")
	_ = json.NewEncoder(w).Encode(adminSessionsSnapshot())
}

func adminHealth(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Content-Type", "application/json; charset=utf-8")
	_, _ = w.Write([]byte(`{"ok":true,"mode":7,"protocol":"STUN-UDP"}`))
}

func adminDisconnect(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "POST required", http.StatusMethodNotAllowed)
		return
	}
	if err := r.ParseForm(); err != nil {
		http.Error(w, "invalid form", http.StatusBadRequest)
		return
	}

	hwid := strings.ToLower(strings.TrimSpace(r.FormValue("hwid")))
	if hwid == "" {
		http.Error(w, "missing hwid", http.StatusBadRequest)
		return
	}

	sessionsMu.RLock()
	sids := make([]string, 0, 1)
	for sid, s := range sessionsBySID {
		if s != nil && strings.EqualFold(strings.TrimSpace(s.HWID), hwid) {
			sids = append(sids, sid)
		}
	}
	sessionsMu.RUnlock()

	for _, sid := range sids {
		removeSession(sid)
	}

	w.Header().Set("Content-Type", "application/json; charset=utf-8")
	_ = json.NewEncoder(w).Encode(map[string]any{
		"ok":           true,
		"hwid":         hwid,
		"disconnected": len(sids),
	})
}

func startAdminServer() {
	mux := http.NewServeMux()
	mux.HandleFunc("/health", adminHealth)
	mux.HandleFunc("/api/sessions", adminSessionsJSON)
	mux.HandleFunc("/api/disconnect", adminDisconnect)

	server := &http.Server{
		Addr:              adminAddr,
		Handler:           mux,
		ReadHeaderTimeout: 3 * time.Second,
		ReadTimeout:       5 * time.Second,
		WriteTimeout:      5 * time.Second,
		IdleTimeout:       30 * time.Second,
	}

	log.Printf("📊 Mode 7 internal API listening on %s", adminAddr)
	if err := server.ListenAndServe(); err != nil && err != http.ErrServerClosed {
		log.Printf("❌ Mode 7 internal API stopped: %v", err)
	}
}

func createTun(name string) (*os.File, error) {
	fd, err := syscall.Open("/dev/net/tun", syscall.O_RDWR, 0)
	if err != nil {
		return nil, err
	}

	req := ifreq{
		Flags: iffTun | iffNoPI,
	}
	copy(req.Name[:], name)

	_, _, errno := syscall.Syscall(
		syscall.SYS_IOCTL,
		uintptr(fd),
		uintptr(tunsetIFF),
		uintptr(unsafe.Pointer(&req)),
	)
	if errno != 0 {
		syscall.Close(fd)
		return nil, errno
	}

	return os.NewFile(uintptr(fd), "/dev/net/tun"), nil
}

func configureTun() error {
	// Delete only tun200's old address/state.
	// Never touch tun100 or 10.4.0.0/24.
	_ = run("ip", "addr", "flush", "dev", tunName)

	if err := run("ip", "addr", "add", tunCIDR, "dev", tunName); err != nil {
		return err
	}

	if err := run("ip", "link", "set", "dev", tunName, "mtu", fmt.Sprint(mtu)); err != nil {
		return err
	}

	if err := run("ip", "link", "set", "dev", tunName, "up"); err != nil {
		return err
	}

	return nil
}

func setupForwardingAndNAT() error {
	if err := run("sysctl", "-w", "net.ipv4.ip_forward=1"); err != nil {
		return err
	}

	// Add only if absent. Do NOT flush existing Mode 6 rules.
	ensureIPTablesRule(
		"-t", "nat",
		"-C", "POSTROUTING",
		"-s", vpnNet,
		"-o", wanIf,
		"-j", "MASQUERADE",
	)

	ensureIPTablesRule(
		"-C", "FORWARD",
		"-s", vpnNet,
		"-i", tunName,
		"-o", wanIf,
		"-j", "ACCEPT",
	)

	ensureIPTablesRule(
		"-C", "FORWARD",
		"-d", vpnNet,
		"-i", wanIf,
		"-o", tunName,
		"-m", "conntrack",
		"--ctstate", "RELATED,ESTABLISHED",
		"-j", "ACCEPT",
	)

	return nil
}

func ensureIPTablesRule(checkArgs ...string) {
	if exec.Command("iptables", checkArgs...).Run() == nil {
		return
	}

	addArgs := append([]string(nil), checkArgs...)

	for i, v := range addArgs {
		if v == "-C" {
			addArgs[i] = "-A"
			break
		}
	}

	if err := run("iptables", addArgs...); err != nil {
		log.Printf("⚠️ iptables rule: %v", err)
	}
}

func detectWANInterface() (string, error) {
	if forced := strings.TrimSpace(os.Getenv("WAN_IFACE")); forced != "" {
		if forced == "lo" { return "", errors.New("WAN_IFACE cannot be loopback") }
		if _, err := net.InterfaceByName(forced); err != nil { return "", err }
		return forced, nil
	}
	out, err := exec.Command("ip", "-4", "route", "get", "1.1.1.1").Output()
	if err != nil { out, err = exec.Command("ip", "-4", "route", "show", "default").Output() }
	if err != nil { return "", err }
	fields := strings.Fields(string(out))
	for i := 0; i+1 < len(fields); i++ {
		if fields[i] == "dev" && fields[i+1] != "lo" {
			if _, err := net.InterfaceByName(fields[i+1]); err != nil { return "", err }
			return fields[i+1], nil
		}
	}
	return "", errors.New("default route has no valid network interface")
}

func udpLoop(conn *net.UDPConn, tun *os.File) {
	buf := make([]byte, 65535)

	for {
		n, addr, err := conn.ReadFromUDP(buf)
		if err != nil {
			log.Printf("❌ UDP read: %v", err)
			continue
		}

		if n <= 0 {
			continue
		}

		packet := make([]byte, n)
		copy(packet, buf[:n])

		switch {
		case isSTUNBindingRequest(packet):
			handleSTUN(conn, addr, packet)

		case strings.HasPrefix(string(packet), handshakePrefix):
			handleHandshake(conn, addr, packet)

		default:
			handleTunnelUpload(conn, tun, addr, packet)
		}
	}
}

func isSTUNBindingRequest(p []byte) bool {
	if len(p) < 20 {
		return false
	}

	msgType := binary.BigEndian.Uint16(p[0:2])
	cookie := binary.BigEndian.Uint32(p[4:8])

	return msgType == 0x0001 && cookie == 0x2112A442
}

func handleSTUN(conn *net.UDPConn, addr *net.UDPAddr, req []byte) {
	if len(req) < 20 {
		return
	}

	txID := req[8:20]

	ip4 := addr.IP.To4()
	if ip4 == nil {
		log.Printf("⚠️ STUN non-IPv4 client: %s", addr)
		return
	}

	// XOR-MAPPED-ADDRESS:
	// Type 0x0020
	// Length 8
	// Reserved 0
	// Family IPv4 = 1
	// X-Port = port XOR upper 16 bits of magic cookie
	// X-Address = IPv4 XOR magic cookie
	attr := make([]byte, 12)

	binary.BigEndian.PutUint16(attr[0:2], 0x0020)
	binary.BigEndian.PutUint16(attr[2:4], 8)

	attr[4] = 0
	attr[5] = 0x01

	xPort := uint16(addr.Port) ^ uint16(0x2112)
	binary.BigEndian.PutUint16(attr[6:8], xPort)

	cookie := []byte{0x21, 0x12, 0xA4, 0x42}
	for i := 0; i < 4; i++ {
		attr[8+i] = ip4[i] ^ cookie[i]
	}

	resp := make([]byte, 20+len(attr))

	// Binding Success Response.
	binary.BigEndian.PutUint16(resp[0:2], 0x0101)
	binary.BigEndian.PutUint16(resp[2:4], uint16(len(attr)))
	binary.BigEndian.PutUint32(resp[4:8], 0x2112A442)
	copy(resp[8:20], txID)
	copy(resp[20:], attr)

	if _, err := conn.WriteToUDP(resp, addr); err != nil {
		log.Printf("❌ STUN reply to %s: %v", addr, err)
		return
	}

	log.Printf(
		"🛰️ STUN OK | FROM=%s | MAPPED=%s:%d",
		addr,
		addr.IP.String(),
		addr.Port,
	)
}

func handleHandshake(conn *net.UDPConn, addr *net.UDPAddr, packet []byte) {
	body := packet[len(handshakePrefix):]
	var outer SecureHandshake
	if err := json.Unmarshal(body, &outer); err != nil || outer.Version != 2 { return }
	clientPub, err := base64.RawURLEncoding.DecodeString(outer.ClientKey)
	if err != nil { return }
	hs, err := newHandshakeCrypto(7, clientPub)
	if err != nil { return }
	sealed, err := base64.RawURLEncoding.DecodeString(outer.Data)
	if err != nil { return }
	body, err = hs.open(sealed)
	if err != nil { return }

	var req HandshakeRequest
	if err := json.Unmarshal(body, &req); err != nil {
		log.Printf("❌ HANDSHAKE invalid JSON | FROM=%s | ERR=%v", addr, err)
		return
	}

	if !strings.EqualFold(req.Mode, "stun-udp") {
		log.Printf(
			"⚠️ HANDSHAKE unexpected mode | FROM=%s | MODE=%q",
			addr,
			req.Mode,
		)
	}

	req.HWID = strings.ToLower(strings.TrimSpace(req.HWID))
	if req.HWID == "" {
		sendHandshakeError(conn, addr, hs, "missing_hwid")
		return
	}

	allowed, status, err := authorizeHWID(req.HWID)
	if err != nil {
		log.Printf("❌ HANDSHAKE authorization unavailable | HWID=%s | ERR=%v", req.HWID, err)
		sendHandshakeError(conn, addr, hs, "authorization_unavailable")
		return
	}
	if !allowed {
		log.Printf("⛔ HANDSHAKE rejected | HWID=%s | STATUS=%s", req.HWID, status)
		sendHandshakeError(conn, addr, hs, status)
		return
	}

	serverSID, err := randomSID()
	if err != nil {
		log.Printf("❌ generate SID: %v", err)
		return
	}

	vpnIP, err := allocateVPNIP()
	if err != nil {
		log.Printf("❌ allocate VPN IP: %v", err)
		return
	}

	now := time.Now()

	session := &Session{
		SID:        serverSID,
		ClientSID:  req.SID,
		HWID:       req.HWID,
		Tag:        req.Tag,
		Root:       req.Root,
		VPNIP:      vpnIP,
		ClientAddr: cloneUDPAddr(addr),
		CreatedAt:  now,
		LastSeen:   now,
		Crypto:     hs.session(serverSID),
	}

	sessionsMu.Lock()
	// A device may repeat the handshake while recovering its UDP path. Keep
	// exactly one live Mode 7 session per HWID so the API and address pool do
	// not accumulate obsolete rows for the same device.
	for oldSID, old := range sessionsBySID {
		if old != nil && strings.EqualFold(strings.TrimSpace(old.HWID), req.HWID) {
			delete(sessionsBySID, oldSID)
			delete(sessionsByIP, old.VPNIP.String())
			log.Printf("♻️ SESSION REPLACED | HWID=%s | OLD_SID=%s | OLD_IP=%s | NEW_SID=%s | NEW_IP=%s",
				req.HWID, oldSID, old.VPNIP, serverSID, vpnIP)
		}
	}
	sessionsBySID[serverSID] = session
	sessionsByIP[vpnIP.String()] = session
	sessionsMu.Unlock()

	respJSON, err := json.Marshal(HandshakeResponse{
		SID: serverSID,
		IP:  vpnIP.String(),
	})
	if err != nil {
		removeSession(serverSID)
		return
	}

	sealedResponse, err := hs.seal(respJSON)
	if err != nil { removeSession(serverSID); return }
	outerResponse, _ := json.Marshal(SecureHandshake{Version: 2, Data: base64.RawURLEncoding.EncodeToString(sealedResponse)})
	resp := append([]byte(handshakePrefix), outerResponse...)

	if _, err := conn.WriteToUDP(resp, addr); err != nil {
		removeSession(serverSID)
		log.Printf("❌ HANDSHAKE reply | FROM=%s | ERR=%v", addr, err)
		return
	}

	log.Printf("🤝 HANDSHAKE OK")
	log.Printf("   FROM       = %s", addr)
	log.Printf("   HWID       = %s", req.HWID)
	log.Printf("   TAG        = %s", req.Tag)
	log.Printf("   CLIENT SID = %s", req.SID)
	log.Printf("   SERVER SID = %s", serverSID)
	log.Printf("   VPN IP     = %s", vpnIP.String())
	log.Printf("   MTU        = %d", req.MTU)
}

func authorizeHWID(hwid string) (bool, string, error) {
	req, err := http.NewRequest(http.MethodGet, authorizeURL, nil)
	if err != nil {
		return false, "", err
	}

	query := req.URL.Query()
	query.Set("hwid", hwid)
	req.URL.RawQuery = query.Encode()

	resp, err := authorizeHTTPClient.Do(req)
	if err != nil {
		return false, "", err
	}
	defer resp.Body.Close()

	if resp.StatusCode != http.StatusOK {
		return false, "", fmt.Errorf("authorization API returned HTTP %d", resp.StatusCode)
	}

	var result AuthorizeResponse
	if err := json.NewDecoder(resp.Body).Decode(&result); err != nil {
		return false, "", err
	}
	return result.Allowed, result.Status, nil
}

func sendHandshakeError(conn *net.UDPConn, addr *net.UDPAddr, hs *handshakeCrypto, message string) {
	body, err := json.Marshal(HandshakeResponse{Error: message})
	if err != nil {
		return
	}
	sealed, err := hs.seal(body); if err != nil { return }
	outer, _ := json.Marshal(SecureHandshake{Version: 2, Data: base64.RawURLEncoding.EncodeToString(sealed)})
	_, _ = conn.WriteToUDP(append([]byte(handshakePrefix), outer...), addr)
}

func handleTunnelUpload(conn *net.UDPConn, tun *os.File, addr *net.UDPAddr, packet []byte) {
	// Server SID is exactly 16 ASCII bytes.
	if len(packet) <= 16 {
		return
	}

	sid := string(packet[:16])

	sessionsMu.RLock()
	s := sessionsBySID[sid]
	sessionsMu.RUnlock()

	if s == nil {
		return
	}

	payload, err := s.Crypto.openFromClient(packet[16:])
	if err != nil { return }

	// An authenticated heartbeat keeps an idle VPN session alive without
	// requiring browsing traffic. Reply through the encrypted session so the
	// Android watchdog can distinguish a live server from a dead UDP path.
	if bytes.Equal(payload, secureKeepalivePayload) {
		sessionsMu.Lock()
		if current := sessionsBySID[sid]; current == s {
			current.ClientAddr = cloneUDPAddr(addr)
			current.LastSeen = time.Now()
		}
		sessionsMu.Unlock()

		ack, sealErr := s.Crypto.sealToClient(secureKeepalivePayload)
		if sealErr == nil {
			out := make([]byte, 16+len(ack))
			copy(out[:16], []byte(sid))
			copy(out[16:], ack)
			_, _ = conn.WriteToUDP(out, addr)
		}
		return
	}
	if len(payload) < 20 {
		return
	}

	// Mode 7 currently carries raw IPv4.
	if payload[0]>>4 != 4 {
		return
	}

	// Security/session sanity check:
	// packet source should be the VPN IP allocated to this SID.
	src := net.IPv4(
		payload[12],
		payload[13],
		payload[14],
		payload[15],
	)

	if !src.Equal(s.VPNIP) {
		log.Printf(
			"⚠️ DROP source mismatch | SID=%s | WANT=%s | GOT=%s",
			sid,
			s.VPNIP,
			src,
		)
		return
	}

	// NAT port can change. A valid SID + VPN source packet
	// refreshes the endpoint.
	sessionsMu.Lock()
	s.ClientAddr = cloneUDPAddr(addr)
	s.LastSeen = time.Now()
	s.Upload += uint64(len(payload))
	sessionsMu.Unlock()

	n, err := tun.Write(payload)
	if err != nil {
		log.Printf("❌ TUN write | SID=%s | ERR=%v", sid, err)
		return
	}

	if n != len(payload) {
		log.Printf(
			"⚠️ short TUN write | SID=%s | WANT=%d | GOT=%d",
			sid,
			len(payload),
			n,
		)
	}
}

func tunReader(tun *os.File, conn *net.UDPConn) {
	buf := make([]byte, 65535)

	for {
		n, err := tun.Read(buf)
		if err != nil {
			log.Printf("❌ TUN read: %v", err)
			time.Sleep(100 * time.Millisecond)
			continue
		}

		if n < 20 {
			continue
		}

		packet := buf[:n]

		if packet[0]>>4 != 4 {
			continue
		}

		// IPv4 destination offset = 16..19.
		dst := net.IPv4(
			packet[16],
			packet[17],
			packet[18],
			packet[19],
		)

		sessionsMu.RLock()
		s := sessionsByIP[dst.String()]

		if s == nil {
			sessionsMu.RUnlock()
			continue
		}

		sid := s.SID
		addr := cloneUDPAddr(s.ClientAddr)
		sessionsMu.RUnlock()

		if addr == nil || len(sid) != 16 {
			continue
		}

		encrypted, err := s.Crypto.sealToClient(packet)
		if err != nil { continue }
		out := make([]byte, 16+len(encrypted))
		copy(out[:16], []byte(sid))
		copy(out[16:], encrypted)

		if _, err := conn.WriteToUDP(out, addr); err != nil {
			log.Printf(
				"❌ DOWNLOAD UDP | SID=%s | TO=%s | ERR=%v",
				sid,
				addr,
				err,
			)
			continue
		}

		sessionsMu.Lock()
		if current := sessionsBySID[sid]; current != nil {
			current.Download += uint64(n)
			current.LastSeen = time.Now()
		}
		sessionsMu.Unlock()
	}
}

func allocateVPNIP() (net.IP, error) {
	sessionsMu.Lock()
	defer sessionsMu.Unlock()

	count := lastClient - firstClient + 1

	for tries := 0; tries < count; tries++ {
		host := nextIP
		nextIP++

		if nextIP > lastClient {
			nextIP = firstClient
		}

		ip := net.IPv4(10, 8, 0, byte(host))

		if _, used := sessionsByIP[ip.String()]; !used {
			return ip, nil
		}
	}

	return nil, errors.New("VPN address pool exhausted")
}

func randomSID() (string, error) {
	b := make([]byte, 8)

	if _, err := rand.Read(b); err != nil {
		return "", err
	}

	// 8 bytes -> exactly 16 lowercase hexadecimal ASCII characters.
	return hex.EncodeToString(b), nil
}

func sessionCleaner() {
	ticker := time.NewTicker(30 * time.Second)
	defer ticker.Stop()

	for range ticker.C {
		now := time.Now()

		sessionsMu.Lock()

		for sid, s := range sessionsBySID {
			// Keep it generous while testing because the client
			// has its own watchdog/re-handshake behavior.
			if now.Sub(s.LastSeen) > 10*time.Minute {
				delete(sessionsBySID, sid)
				delete(sessionsByIP, s.VPNIP.String())

				log.Printf(
					"🧹 SESSION EXPIRED | SID=%s | IP=%s | HWID=%s",
					sid,
					s.VPNIP,
					s.HWID,
				)
			}
		}

		sessionsMu.Unlock()
	}
}

func removeSession(sid string) {
	sessionsMu.Lock()
	defer sessionsMu.Unlock()

	s := sessionsBySID[sid]
	if s == nil {
		return
	}

	delete(sessionsBySID, sid)
	delete(sessionsByIP, s.VPNIP.String())
}

func cloneUDPAddr(a *net.UDPAddr) *net.UDPAddr {
	if a == nil {
		return nil
	}

	ip := make(net.IP, len(a.IP))
	copy(ip, a.IP)

	return &net.UDPAddr{
		IP:   ip,
		Port: a.Port,
		Zone: a.Zone,
	}
}

func sameUDPAddr(a, b *net.UDPAddr) bool {
	if a == nil || b == nil {
		return false
	}

	return a.Port == b.Port && a.IP.Equal(b.IP)
}

func run(name string, args ...string) error {
	cmd := exec.Command(name, args...)

	out, err := cmd.CombinedOutput()
	if err != nil {
		return fmt.Errorf(
			"%s %s: %w: %s",
			name,
			strings.Join(args, " "),
			err,
			strings.TrimSpace(string(out)),
		)
	}

	return nil
}
