module abso-dns-server

go 1.22

require (
	github.com/miekg/dns v1.1.72
	github.com/songgao/water v0.0.0-20200317203138-2b4b6d7c09d8
)
