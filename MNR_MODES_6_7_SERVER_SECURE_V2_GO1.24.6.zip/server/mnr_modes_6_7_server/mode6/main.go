package main

import (
	"bytes"
	"compress/zlib"
	"crypto/rand"
	"crypto/sha256"
	"crypto/subtle"
	"encoding/base32"
	"encoding/base64"
	"encoding/binary"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"log"
	"net"
	"net/http"
	"net/url"
	"os"
	"os/exec"
	"strings"
	"sync"
	"sync/atomic"
	"time"

	"github.com/miekg/dns"
	"github.com/songgao/water"
)

// Normal runtime logging is intentionally silent.
// Only session CONNECTED / SESSION ENDED messages are emitted.
// Fatal startup errors still use the standard logger so failures remain diagnosable.
func silentLogf(format string, args ...any) {}
func silentLogln(args ...any)               {}

const (
	serverSuffix            = "dns.alhoda.indevs.in"
	hwidFile                = "hwids.json"
	authConfigFile          = "auth_config.json"
	vpnNetworkBase          = "10.4.0.0"
	vpnServerIP             = "10.4.0.1"
	vpnCIDR                 = "10.4.0.0/22"
	vpnPrefixLen            = 22
	vpnFirstHost     uint32 = 2
	vpnLastHost      uint32 = 1022
	tunName                 = "tun100"
	tunMTU                  = "1300"
	dnsPort                 = ":53"
	adminAddr               = "0.0.0.0:8080"
	mode7SessionsURL        = "http://127.0.0.1:8081/api/sessions"

	// The Android client uses QTYPE NULL (10) for this profile.
	dataQType = dns.TypeNULL

	// The client-side encoder in o() uses at most 110 bytes after
	// the 4-byte fragment header.
	fragmentPayloadSize = 110

	// Android l() receives the complete zlib stream from one POLL response.
	// Do not use a small 240-byte cap: compressed packets observed in the
	// tunnel are commonly 1200-1360 bytes and must not be truncated/dropped.
	// 1400 bytes keeps the DNS response below the normal Ethernet MTU while
	// leaving room for the DNS header/question/RR overhead.
	serverResponseChunk = 16 * 1024
	sessionQueueSize    = 1024
	fragmentTTL         = 10 * time.Second
	sessionIdleTTL      = 5 * time.Minute
	maxDownstreamBatch  = 64
)

type HWIDStatus string

const (
	StatusPending  HWIDStatus = "pending"
	StatusApproved HWIDStatus = "approved"
	StatusDenied   HWIDStatus = "denied"
)

type HWIDEntry struct {
	HWID          string     `json:"hwid"`
	Status        HWIDStatus `json:"status"`
	FirstSeen     time.Time  `json:"first_seen"`
	LastSeen      time.Time  `json:"last_seen"`
	UploadBytes   uint64     `json:"upload_bytes,omitempty"`
	DownloadBytes uint64     `json:"download_bytes,omitempty"`
}

type AuthConfig struct {
	AutoApprove bool `json:"auto_approve"`
}

type ClientSession struct {
	HWID string
	SID  string
	IP   string
	CreatedAt time.Time
	cryptoMu sync.RWMutex
	crypto   *tunnelCrypto

	activityMu sync.RWMutex
	LastSeen   time.Time

	// Startup timing diagnostics. Reset after every successful handshake.
	startupMu          sync.Mutex
	startupAt          time.Time
	startupUploadSeen  bool
	startupTunDownSeen bool
	startupRDATASeen   bool

	// Server -> Android raw IP packets waiting for poll.
	// They are batched and zlib-compressed only when a POLL arrives.
	Queue chan []byte

	// One packet may be consumed while testing the next batch size. Keep it
	// here so a packet is never dropped merely because it does not fit.
	pendingMu sync.Mutex
	pending   [][]byte

	// Android -> Server fragment reassembly.
	fragMu    sync.Mutex
	fragments map[uint16]*fragmentAssembly
}

type fragmentAssembly struct {
	total      uint8
	parts      map[uint8][]byte
	fragSource map[uint8]string
	createdAt  time.Time
}

var (
	tunIf *water.Interface

	hwidMu   sync.RWMutex
	hwidList = make(map[string]*HWIDEntry)

	authMu     sync.RWMutex
	authConfig AuthConfig
	usageDirty uint32

	sessionMu     sync.Mutex
	sessionByHWID = make(map[string]*ClientSession)

	ipMu    sync.Mutex
	nextIP  uint32 = 2
	usedIPs        = make(map[string]bool)

	sessionsBySID sync.Map
	sessionsByIP  sync.Map

	configMu      sync.Mutex
	configuredTun bool

	wanInterface string

	// Performance counters (reset once per second by perfReporter).
	perfDataQueries        uint64
	perfPollQueries        uint64
	perfUploadFragBytes    uint64
	perfUploadRawBytes     uint64
	perfTunDownloadBytes   uint64
	perfDownloadRDATABytes uint64
	perfOKResponses        uint64
	perfDataResponses      uint64

	// Upload pipeline diagnostics. These counters are observational only.
	perfPktTotal    uint64
	perfPktAccepted uint64
	perfPktSrcDrop  uint64
	perfPktInvalid  uint64
	perfFragRX      uint64
	perfAsmComplete uint64
	perfAsmExpired  uint64
	perfInflateOK   uint64
	perfInflateFail uint64
	perfTCSent      uint64
	perfTCPRetry    uint64
	perfQueueMax    uint64
	// Single-packet UDP fallback histogram. These counters are diagnostic only
	// and do not change protocol behavior.
	perfTC1351To1380 uint64
	perfTC1381To1400 uint64
	perfTC1401To1450 uint64
	perfTC1451Plus   uint64
)

// perfReporter prints one compact line per second and resets interval counters.
// It does not change protocol behavior.
func perfReporter() {
	ticker := time.NewTicker(time.Second)
	defer ticker.Stop()
	for range ticker.C {
		dataQ := atomic.SwapUint64(&perfDataQueries, 0)
		pollQ := atomic.SwapUint64(&perfPollQueries, 0)
		upFrag := atomic.SwapUint64(&perfUploadFragBytes, 0)
		upRaw := atomic.SwapUint64(&perfUploadRawBytes, 0)
		tunDown := atomic.SwapUint64(&perfTunDownloadBytes, 0)
		rdataDown := atomic.SwapUint64(&perfDownloadRDATABytes, 0)
		okResp := atomic.SwapUint64(&perfOKResponses, 0)
		dataResp := atomic.SwapUint64(&perfDataResponses, 0)
		pktTotal := atomic.SwapUint64(&perfPktTotal, 0)
		//pktAccepted := atomic.SwapUint64(&perfPktAccepted, 0)
		//pktSrcDrop := atomic.SwapUint64(&perfPktSrcDrop, 0)
		//pktInvalid := atomic.SwapUint64(&perfPktInvalid, 0)
		fragRX := atomic.SwapUint64(&perfFragRX, 0)
		asmComplete := atomic.SwapUint64(&perfAsmComplete, 0)
		asmExpired := atomic.SwapUint64(&perfAsmExpired, 0)
		inflateOK := atomic.SwapUint64(&perfInflateOK, 0)
		inflateFail := atomic.SwapUint64(&perfInflateFail, 0)
		tcSent := atomic.SwapUint64(&perfTCSent, 0)
		tcpRetry := atomic.SwapUint64(&perfTCPRetry, 0)
		queueMax := atomic.SwapUint64(&perfQueueMax, 0)
		tc1351To1380 := atomic.SwapUint64(&perfTC1351To1380, 0)
		tc1381To1400 := atomic.SwapUint64(&perfTC1381To1400, 0)
		tc1401To1450 := atomic.SwapUint64(&perfTC1401To1450, 0)
		tc1451Plus := atomic.SwapUint64(&perfTC1451Plus, 0)

		totalResp := okResp + dataResp
		avgRDATA := uint64(0)
		if dataResp > 0 {
			avgRDATA = rdataDown / dataResp
		}

		// Avoid log spam while completely idle.
		if dataQ == 0 && pollQ == 0 && upFrag == 0 && upRaw == 0 && tunDown == 0 && totalResp == 0 &&
			pktTotal == 0 && fragRX == 0 && asmComplete == 0 && asmExpired == 0 && inflateOK == 0 && inflateFail == 0 && tcSent == 0 && tcpRetry == 0 {
			continue
		}

		silentLogf("📊 PERF | DATAq/s=%d POLLq/s=%d | ASM ok=%d exp=%d | UPraw=%dB/s | TUNdown=%dB/s RDATAout=%dB/s avgRDATA=%dB | RESP data=%d ok=%d | Qmax=%d | TC=%d TCPretry=%d | TCsize 1351-1380=%d 1381-1400=%d 1401-1450=%d 1451+=%d",
			dataQ, pollQ, asmComplete, asmExpired, upRaw, tunDown, rdataDown, avgRDATA,
			dataResp, okResp, queueMax, tcSent, tcpRetry,
			tc1351To1380, tc1381To1400, tc1401To1450, tc1451Plus)
	}
}

func resetStartupMetrics(s *ClientSession) {
	s.startupMu.Lock()
	s.startupAt = time.Now()
	s.startupUploadSeen = false
	s.startupTunDownSeen = false
	s.startupRDATASeen = false
	s.startupMu.Unlock()
}

func logStartupEvent(s *ClientSession, kind string) {
	s.startupMu.Lock()
	defer s.startupMu.Unlock()
	if s.startupAt.IsZero() {
		return
	}
	var seen *bool
	switch kind {
	case "FIRST_UPLOAD":
		seen = &s.startupUploadSeen
	case "FIRST_TUN_DOWN":
		seen = &s.startupTunDownSeen
	case "FIRST_RDATA":
		seen = &s.startupRDATASeen
	default:
		return
	}
	if *seen {
		return
	}
	*seen = true
	silentLogf("⏱️ STARTUP | %s | SID=%s | after=%s", kind, s.SID, time.Since(s.startupAt).Round(time.Millisecond))
}

// ------------------------------------------------------------
// Generic helpers
// ------------------------------------------------------------

func run(cmd string, args ...string) error {
	c := exec.Command(cmd, args...)
	out, err := c.CombinedOutput()
	if err != nil {
		return fmt.Errorf("%s %s: %w: %s", cmd, strings.Join(args, " "), err, strings.TrimSpace(string(out)))
	}
	return nil
}

func mustRoot() {
	if os.Geteuid() != 0 {
		log.Fatal("❌ This server must run as root")
	}
}

// ------------------------------------------------------------
// HWID database + authorization mode
// ------------------------------------------------------------

func loadAuthConfig() error {
	data, err := os.ReadFile(authConfigFile)
	if os.IsNotExist(err) {
		authMu.Lock()
		authConfig = AuthConfig{AutoApprove: false}
		authMu.Unlock()
		return nil
	}
	if err != nil {
		return err
	}

	var cfg AuthConfig
	if err := json.Unmarshal(data, &cfg); err != nil {
		return err
	}

	authMu.Lock()
	authConfig = cfg
	authMu.Unlock()
	return nil
}

func saveAuthConfig() error {
	authMu.RLock()
	cfg := authConfig
	authMu.RUnlock()

	data, err := json.MarshalIndent(cfg, "", "  ")
	if err != nil {
		return err
	}

	tmp := authConfigFile + ".tmp"
	if err := os.WriteFile(tmp, data, 0600); err != nil {
		return err
	}
	return os.Rename(tmp, authConfigFile)
}

func isAutoApproveEnabled() bool {
	authMu.RLock()
	v := authConfig.AutoApprove
	authMu.RUnlock()
	return v
}

func setAutoApprove(enabled bool) error {
	authMu.Lock()
	authConfig.AutoApprove = enabled
	authMu.Unlock()

	silentLogf("🔐 AUTH MODE | auto_approve=%v", enabled)
	return saveAuthConfig()
}

func addHWIDUsage(hwid string, upload, download uint64) {
	if upload == 0 && download == 0 {
		return
	}
	hwid = strings.ToLower(strings.TrimSpace(hwid))

	hwidMu.Lock()
	if e, ok := hwidList[hwid]; ok && e != nil {
		e.UploadBytes += upload
		e.DownloadBytes += download
		atomic.StoreUint32(&usageDirty, 1)
	}
	hwidMu.Unlock()
}

func usageSaver() {
	ticker := time.NewTicker(15 * time.Second)
	defer ticker.Stop()

	for range ticker.C {
		if atomic.SwapUint32(&usageDirty, 0) == 0 {
			continue
		}
		if err := saveHWIDs(); err != nil {
			atomic.StoreUint32(&usageDirty, 1)
			silentLogf("⚠️ Cannot persist usage counters: %v", err)
		}
	}
}

func loadHWIDs() error {
	data, err := os.ReadFile(hwidFile)
	if os.IsNotExist(err) {
		return nil
	}
	if err != nil {
		return err
	}

	var entries []HWIDEntry
	if err := json.Unmarshal(data, &entries); err != nil {
		return err
	}

	hwidMu.Lock()
	defer hwidMu.Unlock()

	for i := range entries {
		e := entries[i]
		hwidList[strings.ToLower(strings.TrimSpace(e.HWID))] = &e
	}
	return nil
}

func saveHWIDs() error {
	hwidMu.RLock()
	entries := make([]HWIDEntry, 0, len(hwidList))
	for _, e := range hwidList {
		entries = append(entries, *e)
	}
	hwidMu.RUnlock()

	data, err := json.MarshalIndent(entries, "", "  ")
	if err != nil {
		return err
	}

	tmp := hwidFile + ".tmp"
	if err := os.WriteFile(tmp, data, 0644); err != nil {
		return err
	}
	return os.Rename(tmp, hwidFile)
}

func getHWIDStatus(hwid string) HWIDStatus {
	hwid = strings.ToLower(strings.TrimSpace(hwid))
	auto := isAutoApproveEnabled()

	hwidMu.RLock()
	e, ok := hwidList[hwid]
	hwidMu.RUnlock()

	if !ok {
		now := time.Now()
		initialStatus := StatusPending
		if auto {
			initialStatus = StatusApproved
		}

		e = &HWIDEntry{
			HWID:      hwid,
			Status:    initialStatus,
			FirstSeen: now,
			LastSeen:  now,
		}

		hwidMu.Lock()
		if old, exists := hwidList[hwid]; exists {
			e = old
		} else {
			hwidList[hwid] = e
			if initialStatus == StatusApproved {
				silentLogf("🆕 NEW HWID: %s -> AUTO APPROVED", hwid)
			} else {
				silentLogf("🆕 NEW HWID REQUEST: %s -> PENDING", hwid)
			}
		}
		hwidMu.Unlock()

		if err := saveHWIDs(); err != nil {
			silentLogf("⚠️ Cannot save HWID database: %v", err)
		}
		return e.Status
	}

	changed := false
	hwidMu.Lock()
	e.LastSeen = time.Now()
	// Auto mode grants pending devices when they actually try to connect.
	// Explicitly denied devices remain blocked even while auto mode is enabled.
	if auto && e.Status == StatusPending {
		e.Status = StatusApproved
		changed = true
		silentLogf("✅ AUTO APPROVED | HWID=%s", hwid)
	}
	status := e.Status
	hwidMu.Unlock()

	if changed {
		if err := saveHWIDs(); err != nil {
			silentLogf("⚠️ Cannot save auto-approved HWID: %v", err)
		}
	}
	return status
}

func setHWIDStatus(hwid string, status HWIDStatus) error {
	hwid = strings.ToLower(strings.TrimSpace(hwid))

	hwidMu.Lock()
	e, ok := hwidList[hwid]
	if !ok {
		now := time.Now()
		e = &HWIDEntry{HWID: hwid, FirstSeen: now}
		hwidList[hwid] = e
	}
	e.Status = status
	e.LastSeen = time.Now()
	hwidMu.Unlock()

	silentLogf("🔐 HWID %s -> %s", hwid, status)
	return saveHWIDs()
}

// ------------------------------------------------------------
// Session/IP
// ------------------------------------------------------------

func allocateClientIP() (string, error) {
	ipMu.Lock()
	defer ipMu.Unlock()

	// 10.4.0.0/22 contains 1024 addresses. Reserve 10.4.0.0 as the
	// network address, 10.4.0.1 for tun100, and 10.4.3.255 as broadcast.
	// Client addresses therefore span host offsets 2..1022 (1021 slots).
	baseIP := net.ParseIP(vpnNetworkBase).To4()
	if baseIP == nil {
		return "", errors.New("invalid VPN network base")
	}
	base := binary.BigEndian.Uint32(baseIP)
	capacity := int(vpnLastHost - vpnFirstHost + 1)

	for n := 0; n < capacity; n++ {
		value := nextIP
		if value < vpnFirstHost || value > vpnLastHost {
			value = vpnFirstHost
		}

		nextIP = value + 1
		if nextIP > vpnLastHost {
			nextIP = vpnFirstHost
		}

		ipBytes := make(net.IP, net.IPv4len)
		binary.BigEndian.PutUint32(ipBytes, base+value)
		ip := ipBytes.String()
		if !usedIPs[ip] {
			usedIPs[ip] = true
			return ip, nil
		}
	}
	return "", errors.New("no free client IP available")
}

func releaseClientIP(ip string) {
	ipMu.Lock()
	delete(usedIPs, ip)
	ipMu.Unlock()
}

func generateSID() string {
	var b [8]byte
	if _, err := rand.Read(b[:]); err != nil {
		return fmt.Sprintf("%016x", time.Now().UnixNano())
	}
	return fmt.Sprintf("%x", b[:])
}

func getOrCreateSession(hwid string) (*ClientSession, error) {
	hwid = strings.ToLower(strings.TrimSpace(hwid))

	sessionMu.Lock()
	defer sessionMu.Unlock()

	if s, ok := sessionByHWID[hwid]; ok {
		touchSession(s)
		return s, nil
	}

	ip, err := allocateClientIP()
	if err != nil {
		return nil, err
	}

	sid := generateSID()
	now := time.Now()
	s := &ClientSession{
		HWID:      hwid,
		SID:       sid,
		IP:        ip,
		CreatedAt: now,
		LastSeen:  now,
		Queue:     make(chan []byte, sessionQueueSize),
		fragments: make(map[uint16]*fragmentAssembly),
	}

	sessionByHWID[hwid] = s
	sessionsBySID.Store(sid, s)
	sessionsByIP.Store(ip, s)

	log.Printf("✅ CONNECTED | HWID=%s | SID=%s | IP=%s", hwid, sid, ip)
	return s, nil
}

func getSessionBySID(sid string) (*ClientSession, bool) {
	v, ok := sessionsBySID.Load(sid)
	if !ok {
		return nil, false
	}
	s, ok := v.(*ClientSession)
	return s, ok
}

func touchSession(s *ClientSession) {
	if s == nil {
		return
	}
	s.activityMu.Lock()
	s.LastSeen = time.Now()
	s.activityMu.Unlock()
}

func sessionLastSeen(s *ClientSession) time.Time {
	if s == nil {
		return time.Time{}
	}
	s.activityMu.RLock()
	t := s.LastSeen
	s.activityMu.RUnlock()
	return t
}

// sessionCleaner releases stale Mode 6 sessions and their /24 addresses.
// It changes only in-memory transport state; HWID approval records are retained.
func sessionCleaner() {
	ticker := time.NewTicker(time.Minute)
	defer ticker.Stop()

	for range ticker.C {
		now := time.Now()
		expired := 0

		sessionMu.Lock()
		for hwid, s := range sessionByHWID {
			if s == nil || now.Sub(sessionLastSeen(s)) <= sessionIdleTTL {
				continue
			}

			delete(sessionByHWID, hwid)
			sessionsBySID.Delete(s.SID)
			sessionsByIP.Delete(s.IP)
			releaseClientIP(s.IP)
			log.Printf("🔌 SESSION ENDED | HWID=%s | SID=%s | IP=%s", s.HWID, s.SID, s.IP)
			expired++
		}
		sessionMu.Unlock()

		if expired > 0 {
			silentLogf("🧹 SESSION CLEANUP | expired=%d | idle>%s", expired, sessionIdleTTL)
		}
	}
}

// cleanupOldVPNState removes only transient state left by an earlier
// server process. It does NOT touch hwids.json or HWID approval status.
func cleanupOldVPNState() {
	// Old NAT/conntrack flows can continue returning packets to 10.4.0.2
	// after the Go process has restarted, while the in-memory session maps
	// are empty. Delete those stale flows before accepting a new session.
	if _, err := exec.LookPath("conntrack"); err == nil {
		_ = exec.Command("conntrack", "-D", "-s", vpnCIDR).Run()
		_ = exec.Command("conntrack", "-D", "-d", vpnCIDR).Run()
	}

	// A crashed/previous process may leave tun100 behind. water.New cannot
	// recreate the same interface name while it still exists.
	_ = exec.Command("ip", "link", "del", tunName).Run()

	silentLogf("🧹 Old VPN transient state cleaned | VPN=%s | TUN=%s", vpnCIDR, tunName)
}

// ------------------------------------------------------------
// TUN + Linux routing/NAT
// ------------------------------------------------------------

func setupTunInterface() (*water.Interface, error) {
	config := water.Config{DeviceType: water.TUN}
	config.Name = tunName

	iface, err := water.New(config)
	if err != nil {
		return nil, fmt.Errorf("failed to create TUN: %w", err)
	}

	// water creates the device, but it does not configure the Linux
	// address/route for us.
	if err := run("ip", "addr", "flush", "dev", tunName); err != nil {
		return nil, err
	}
	if err := run("ip", "addr", "add", fmt.Sprintf("%s/%d", vpnServerIP, vpnPrefixLen), "dev", tunName); err != nil {
		return nil, err
	}
	if err := run("ip", "link", "set", "dev", tunName, "mtu", tunMTU); err != nil {
		return nil, err
	}
	if err := run("ip", "link", "set", "dev", tunName, "up"); err != nil {
		return nil, err
	}

	silentLogf("✅ TUN %s configured: %s/%d UP", tunName, vpnServerIP, vpnPrefixLen)
	return iface, nil
}

func detectWANInterface() (string, error) {
	if forced := strings.TrimSpace(os.Getenv("WAN_IFACE")); forced != "" {
		return forced, nil
	}

	out, err := exec.Command("ip", "route", "show", "default").Output()
	if err != nil {
		return "", fmt.Errorf("cannot detect WAN interface: %w", err)
	}

	fields := strings.Fields(string(out))
	for i := 0; i+1 < len(fields); i++ {
		if fields[i] == "dev" {
			return fields[i+1], nil
		}
	}
	return "", errors.New("default route has no dev field")
}

func ensureIptablesRule(table string, args ...string) error {
	check := []string{}
	if table != "" {
		check = append(check, "-t", table)
	}
	check = append(check, "-C")
	check = append(check, args...)
	if exec.Command("iptables", check...).Run() == nil {
		return nil
	}

	insert := []string{}
	if table != "" {
		insert = append(insert, "-t", table)
	}
	insert = append(insert, "-I")
	insert = append(insert, args...)
	return run("iptables", insert...)
}

func deleteIptablesRuleAll(table string, args ...string) {
	for {
		check := []string{}
		if table != "" {
			check = append(check, "-t", table)
		}
		check = append(check, "-C")
		check = append(check, args...)
		if exec.Command("iptables", check...).Run() != nil {
			return
		}

		del := []string{}
		if table != "" {
			del = append(del, "-t", table)
		}
		del = append(del, "-D")
		del = append(del, args...)
		if exec.Command("iptables", del...).Run() != nil {
			return
		}
	}
}

func enableForwardingAndNAT() error {
	if err := run("sysctl", "-w", "net.ipv4.ip_forward=1"); err != nil {
		return err
	}

	var err error
	wanInterface, err = detectWANInterface()
	if err != nil {
		return err
	}

	// Remove exact legacy /24 rules left by pre-/22 builds. This is safe and
	// idempotent; it does not flush unrelated firewall rules.
	legacyCIDR := "10.4.0.0/24"
	deleteIptablesRuleAll("", "FORWARD", "-i", tunName, "-o", wanInterface, "-s", legacyCIDR, "-j", "ACCEPT")
	deleteIptablesRuleAll("", "FORWARD", "-i", wanInterface, "-o", tunName, "-d", legacyCIDR, "-m", "conntrack", "--ctstate", "ESTABLISHED,RELATED", "-j", "ACCEPT")
	deleteIptablesRuleAll("nat", "POSTROUTING", "-s", legacyCIDR, "-o", wanInterface, "-j", "MASQUERADE")

	if err := ensureIptablesRule("", "FORWARD",
		"-i", tunName, "-o", wanInterface,
		"-s", vpnCIDR, "-j", "ACCEPT"); err != nil {
		return err
	}

	if err := ensureIptablesRule("", "FORWARD",
		"-i", wanInterface, "-o", tunName,
		"-d", vpnCIDR,
		"-m", "conntrack", "--ctstate", "ESTABLISHED,RELATED",
		"-j", "ACCEPT"); err != nil {
		return err
	}

	if err := ensureIptablesRule("nat", "POSTROUTING",
		"-s", vpnCIDR, "-o", wanInterface,
		"-j", "MASQUERADE"); err != nil {
		return err
	}

	silentLogf("🌐 IPv4 forwarding + MASQUERADE enabled | WAN=%s | VPN=%s", wanInterface, vpnCIDR)
	return nil
}

// ------------------------------------------------------------
// Handshake
// ------------------------------------------------------------

func parseHandshake(name string) (string, *handshakeCrypto, bool) {
	name = strings.TrimSuffix(strings.ToLower(name), ".")
	parts := strings.Split(name, ".")

	if len(parts) < 9 || parts[0] != "0-handshake-v2" {
		return "", nil, false
	}
	n := len(parts)
	if !isAllowedTunnelDomainLabel(parts[n-4]) || parts[n-3] != "alhoda" ||
		parts[n-2] != "indevs" || parts[n-1] != "in" {
		return "", nil, false
	}
	pub, err := b32.DecodeString(parts[1] + parts[2])
	if err != nil || len(pub) != 65 { return "", nil, false }
	hs, err := newHandshakeCrypto(6, pub)
	if err != nil { return "", nil, false }
	sealed, err := b32.DecodeString(strings.Join(parts[3:n-4], ""))
	if err != nil { return "", nil, false }
	plain, err := hs.open(sealed)
	if err != nil { return "", nil, false }
	hwid := strings.ToLower(strings.TrimSpace(string(plain)))
	if hwid == "" {
		return "", nil, false
	}
	return hwid, hs, true
}

// Accept dns.alhoda.indevs.in as well as numbered server aliases such as
// dns1.alhoda.indevs.in and dns2.alhoda.indevs.in. Other prefixes are rejected.
func isAllowedTunnelDomainLabel(label string) bool {
	if label == "dns" {
		return true
	}
	if !strings.HasPrefix(label, "dns") || len(label) == 3 {
		return false
	}
	for _, ch := range label[3:] {
		if ch < '0' || ch > '9' {
			return false
		}
	}
	return true
}

func writeNULLResponse(m *dns.Msg, q dns.Question, data []byte) {
	m.Answer = append(m.Answer, &dns.NULL{
		Hdr: dns.RR_Header{
			Name:   q.Name,
			Rrtype: dns.TypeNULL,
			Class:  dns.ClassINET,
			Ttl:    1,
		},
		Data: string(data),
	})
}

func handshakeResponse(r *dns.Msg, q dns.Question, hs *handshakeCrypto, status, ip, sid, errText string) *dns.Msg {
	data, _ := json.Marshal(map[string]string{
		"status": status,
		"ip":     ip,
		"sid":    sid,
		"error":  errText,
	})
	data, _ = hs.seal(data)

	m := new(dns.Msg)
	m.SetReply(r)
	m.Compress = false
	writeNULLResponse(m, q, data)
	return m
}

func handleHandshake(w dns.ResponseWriter, r *dns.Msg, q dns.Question) {
	hwid, hs, ok := parseHandshake(q.Name)
	if !ok {
		dns.HandleFailed(w, r)
		return
	}

	if q.Qtype != dns.TypeNULL {
		m := new(dns.Msg)
		m.SetReply(r)
		m.Rcode = dns.RcodeRefused
		_ = w.WriteMsg(m)
		return
	}

	status := getHWIDStatus(hwid)

	if status == StatusDenied {
		_ = w.WriteMsg(handshakeResponse(r, q, hs, "denied", "", "", "device_not_allowed"))
		return
	}
	if status == StatusPending {
		_ = w.WriteMsg(handshakeResponse(r, q, hs, "pending", "", "", "device_pending"))
		return
	}

	sess, err := getOrCreateSession(hwid)
	if err != nil {
		_ = w.WriteMsg(handshakeResponse(r, q, hs, "error", "", "", "no_ip_available"))
		return
	}

	touchSession(sess)
	resetStartupMetrics(sess)
	sess.cryptoMu.Lock()
	sess.crypto = hs.session(sess.SID)
	sess.cryptoMu.Unlock()

	m := handshakeResponse(r, q, hs, "ok", sess.IP, sess.SID, "")
	silentLogf("✅ APPROVED | HWID=%s | IP=%s | SID=%s", hwid, sess.IP, sess.SID)
	_ = w.WriteMsg(m)
}

// ------------------------------------------------------------
// Client DNS data parsing
// ------------------------------------------------------------

var b32 = base32.NewEncoding("abcdefghijklmnopqrstuvwxyz234567").WithPadding(base32.NoPadding)

func parseDataQuery(name string) (sid string, encoded string, isPoll bool, ok bool) {
	name = strings.TrimSuffix(strings.ToLower(name), ".")
	parts := strings.Split(name, ".")
	if len(parts) < 3 {
		return "", "", false, false
	}

	// suffix must be exact
	n := len(parts)
	if parts[n-3] != "dns" || parts[n-2] != "alhoda" || parts[n-1] != "indevs" {
		// We need the full suffix including "in"; normal split below handles it.
	}
	if n < 5 || !isAllowedTunnelDomainLabel(parts[n-4]) || parts[n-3] != "alhoda" ||
		parts[n-2] != "indevs" || parts[n-1] != "in" {
		return "", "", false, false
	}

	// Client form observed:
	// 0-<base32>.s<SID>.dns.alhoda.indevs.in
	// or:
	// 0-<label>.<label>... .s<SID>.dns.alhoda.indevs.in
	bodyEnd := n - 4
	if bodyEnd < 2 {
		return "", "", false, false
	}

	sidLabel := parts[n-5]
	if !strings.HasPrefix(sidLabel, "s") || len(sidLabel) < 2 {
		return "", "", false, false
	}
	sid = sidLabel[1:]

	if parts[0] == "0-poll" {
		return sid, "", true, true
	}

	if !strings.HasPrefix(parts[0], "0-") {
		return "", "", false, false
	}

	var labels []string
	for i := 0; i < n-5; i++ {
		if parts[i] == "" {
			return "", "", false, false
		}
		if i == 0 {
			labels = append(labels, strings.TrimPrefix(parts[i], "0-"))
		} else {
			labels = append(labels, parts[i])
		}
	}

	encoded = strings.Join(labels, "")
	if encoded == "" {
		return "", "", false, false
	}

	return sid, encoded, false, true
}

func decodeFragment(encoded string) (seq uint16, index, total uint8, payload []byte, err error) {
	encoded = strings.ToLower(strings.ReplaceAll(encoded, ".", ""))
	raw, err := b32.DecodeString(encoded)
	if err != nil {
		return 0, 0, 0, nil, err
	}
	if len(raw) < 4 {
		return 0, 0, 0, nil, errors.New("fragment too short")
	}

	header := binary.BigEndian.Uint32(raw[:4])
	seq = uint16(header >> 16)
	index = uint8(header >> 8)
	total = uint8(header)

	if total == 0 || index >= total {
		return 0, 0, 0, nil, errors.New("invalid fragment header")
	}
	return seq, index, total, raw[4:], nil
}

func (s *ClientSession) addFragment(seq uint16, index, total uint8, payload []byte, source string) ([]byte, bool) {
	s.fragMu.Lock()
	defer s.fragMu.Unlock()

	now := time.Now()

	// Diagnostic only: when an assembly expires, report exactly which
	// fragment indexes never arrived. Protocol behavior is unchanged.
	for k, a := range s.fragments {
		if now.Sub(a.createdAt) > fragmentTTL {
			missing := make([]uint8, 0)
			for i := uint8(0); i < a.total; i++ {
				if _, exists := a.parts[i]; !exists {
					missing = append(missing, i)
				}
			}

			age := now.Sub(a.createdAt).Round(time.Millisecond)

			// With DNS_MULTI=true the client round-robins queries over six TCP
			// slots. Group missing fragment indexes modulo 6; repeated residues
			// reveal whether one/more resolver slots are losing whole queries.
			var slotMissing [6]int
			for _, idx := range missing {
				slotMissing[int(idx)%6]++
			}

			present := make([]string, 0, len(a.parts))
			for i := uint8(0); i < a.total; i++ {
				if _, exists := a.parts[i]; exists {
					present = append(present, fmt.Sprintf("%d@%s", i, a.fragSource[i]))
				}
			}

			silentLogf("🧩 ASM EXPIRE | SID=%s | seq=%d | have=%d want=%d | missing=%v | missBySlot=%v | present=%v | age=%s",
				s.SID, k, len(a.parts), a.total, missing, slotMissing, present, age)

			delete(s.fragments, k)
			atomic.AddUint64(&perfAsmExpired, 1)
		}
	}

	a := s.fragments[seq]
	if a == nil || a.total != total {
		a = &fragmentAssembly{
			total:      total,
			parts:      make(map[uint8][]byte),
			fragSource: make(map[uint8]string),
			createdAt:  now,
		}
		s.fragments[seq] = a
	}

	if _, exists := a.parts[index]; !exists {
		a.parts[index] = append([]byte(nil), payload...)
		a.fragSource[index] = source
	}

	if len(a.parts) != int(a.total) {
		return nil, false
	}

	var out bytes.Buffer
	for i := uint8(0); i < a.total; i++ {
		p, exists := a.parts[i]
		if !exists {
			return nil, false
		}
		out.Write(p)
	}

	age := now.Sub(a.createdAt).Round(time.Millisecond)
	//assembledBytes := out.Len()

	delete(s.fragments, seq)
	atomic.AddUint64(&perfAsmComplete, 1)

	// Keep COMPLETE logging intentionally selective: slow/multi-fragment
	// assemblies are the useful cases for diagnosing startup delay.
	if a.total > 1 || age >= 100*time.Millisecond {
	}

	return out.Bytes(), true
}

func inflateClientStream(data []byte) ([]byte, error) {
	zr, err := zlib.NewReader(bytes.NewReader(data))
	if err != nil {
		return nil, err
	}
	defer zr.Close()

	out, err := io.ReadAll(io.LimitReader(zr, 4*1024*1024))
	if err != nil {
		return nil, err
	}
	return out, nil
}

func deliverLengthPrefixedPackets(s *ClientSession, stream []byte) error {
	r := bytes.NewReader(stream)

	for r.Len() > 0 {
		if r.Len() < 2 {
			return errors.New("truncated packet length")
		}

		var n uint16
		if err := binary.Read(r, binary.BigEndian, &n); err != nil {
			return err
		}
		if n == 0 || int(n) > r.Len() {
			return errors.New("invalid packet length")
		}

		packet := make([]byte, int(n))
		if _, err := io.ReadFull(r, packet); err != nil {
			return err
		}

		atomic.AddUint64(&perfPktTotal, 1)

		if len(packet) < 20 || packet[0]>>4 != 4 {
			atomic.AddUint64(&perfPktInvalid, 1)
			continue
		}
		ihl := int(packet[0]&0x0f) * 4
		if ihl < 20 || ihl > len(packet) {
			atomic.AddUint64(&perfPktInvalid, 1)
			continue
		}
		totalLen := int(binary.BigEndian.Uint16(packet[2:4]))
		if totalLen != len(packet) {
			atomic.AddUint64(&perfPktInvalid, 1)
			continue
		}
		src := net.IPv4(packet[12], packet[13], packet[14], packet[15]).String()
		if src != s.IP {
			atomic.AddUint64(&perfPktSrcDrop, 1)
			continue
		}

		if tunIf == nil {
			return errors.New("TUN is not available")
		}

		if _, err := tunIf.Write(packet); err != nil {
			return err
		}
		atomic.AddUint64(&perfPktAccepted, 1)
		atomic.AddUint64(&perfUploadRawBytes, uint64(len(packet)))
		addHWIDUsage(s.HWID, uint64(len(packet)), 0)
	}

	return nil
}

func handleClientData(s *ClientSession, encoded string, source string) {
	logStartupEvent(s, "FIRST_UPLOAD")
	seq, index, total, payload, err := decodeFragment(encoded)
	if err != nil {
		silentLogf("⚠️ Fragment decode failed | SID=%s | %v", s.SID, err)
		return
	}
	atomic.AddUint64(&perfFragRX, 1)
	atomic.AddUint64(&perfUploadFragBytes, uint64(len(payload)))

	stream, complete := s.addFragment(seq, index, total, payload, source)
	if !complete {
		return
	}

	s.cryptoMu.RLock()
	cryptoSession := s.crypto
	s.cryptoMu.RUnlock()
	if cryptoSession == nil { return }
	stream, err = cryptoSession.openFromClient(stream)
	if err != nil {
		silentLogf("encrypted upload rejected | SID=%s | %v", s.SID, err)
		return
	}
	plain, err := inflateClientStream(stream)
	if err != nil {
		atomic.AddUint64(&perfInflateFail, 1)
		silentLogf("⚠️ zlib inflate failed | SID=%s | %v", s.SID, err)
		return
	}
	atomic.AddUint64(&perfInflateOK, 1)

	if err := deliverLengthPrefixedPackets(s, plain); err != nil {
		silentLogf("⚠️ TUN delivery failed | SID=%s | %v", s.SID, err)
	}
}

// ------------------------------------------------------------
// Server -> Android
//
// Android has IS_BATCHED=true. The inbound client method l() expects
// the POLL response RDATA to be the zlib-compressed stream directly.
// After inflate(), Android reads:
//   uint16 packetLength + packet bytes
// repeatedly.
//
// IMPORTANT: do NOT add the 4-byte fragment header used by Android o().
// That header belongs to Android -> Server only. The previous server
// implementation incorrectly added it downstream, so l() tried to
// inflate data beginning with the fragment header and could not decode it.
// ------------------------------------------------------------

func enqueueServerPacket(s *ClientSession, packet []byte) bool {
	if len(packet) == 0 {
		return false
	}

	// Keep the complete IP packet. The Android side expects the final
	// zlib stream to contain: uint16 length + complete packet.
	select {
	case s.Queue <- append([]byte(nil), packet...):
		qlen := uint64(len(s.Queue))
		for {
			old := atomic.LoadUint64(&perfQueueMax)
			if qlen <= old || atomic.CompareAndSwapUint64(&perfQueueMax, old, qlen) {
				break
			}
		}
		return true
	default:
		silentLogf("⚠️ Session queue full | SID=%s | PACKET=%d", s.SID, len(packet))
		return false
	}
}

func compressDownstreamPackets(packets [][]byte) ([]byte, error) {
	var stream bytes.Buffer
	for _, packet := range packets {
		if len(packet) == 0 || len(packet) > 65535 {
			continue
		}
		if err := binary.Write(&stream, binary.BigEndian, uint16(len(packet))); err != nil {
			return nil, err
		}
		if _, err := stream.Write(packet); err != nil {
			return nil, err
		}
	}

	var compressed bytes.Buffer
	zw, err := zlib.NewWriterLevel(&compressed, zlib.BestSpeed)
	if err != nil {
		return nil, err
	}
	if _, err := zw.Write(stream.Bytes()); err != nil {
		_ = zw.Close()
		return nil, err
	}
	if err := zw.Close(); err != nil {
		return nil, err
	}
	return append([]byte(nil), compressed.Bytes()...), nil
}

func takePendingPacket(s *ClientSession) []byte {
	s.pendingMu.Lock()
	defer s.pendingMu.Unlock()
	if len(s.pending) == 0 {
		return nil
	}
	p := s.pending[0]
	copy(s.pending, s.pending[1:])
	s.pending[len(s.pending)-1] = nil
	s.pending = s.pending[:len(s.pending)-1]
	return p
}

// putPendingPacket places a packet at the front so retry ordering is preserved.
func putPendingPacket(s *ClientSession, packet []byte) {
	if len(packet) == 0 {
		return
	}
	p := append([]byte(nil), packet...)
	s.pendingMu.Lock()
	s.pending = append(s.pending, nil)
	copy(s.pending[1:], s.pending[:len(s.pending)-1])
	s.pending[0] = p
	s.pendingMu.Unlock()
}

func takeNextDownstreamPacket(s *ClientSession) ([]byte, bool) {
	if p := takePendingPacket(s); len(p) > 0 {
		return p, true
	}
	select {
	case p := <-s.Queue:
		return p, true
	default:
		return nil, false
	}
}

func tunReader() {
	if tunIf == nil {
		return
	}

	buf := make([]byte, 65535)
	for {
		n, err := tunIf.Read(buf)
		if err != nil {
			silentLogf("❌ TUN read stopped: %v", err)
			return
		}
		if n < 20 || buf[0]>>4 != 4 {
			continue
		}

		dst := net.IPv4(buf[16], buf[17], buf[18], buf[19]).String()
		v, ok := sessionsByIP.Load(dst)
		if !ok {
			continue
		}
		s, ok := v.(*ClientSession)
		if !ok {
			continue
		}

		// Do NOT compress each packet separately here. Android l() with
		// IS_BATCHED=true expects one complete zlib stream per POLL, and after
		// inflate() it reads repeated: uint16 length + packet.
		packet := append([]byte(nil), buf[:n]...)
		logStartupEvent(s, "FIRST_TUN_DOWN")
		atomic.AddUint64(&perfTunDownloadBytes, uint64(n))
		if enqueueServerPacket(s, packet) {
			addHWIDUsage(s.HWID, 0, uint64(n))
		}
		//silentLogf("⬆️ INTERNET -> QUEUE | SID=%s | DST=%s | PACKET=%d", s.SID, dst, n)
	}
}

func transportDataLimit(w dns.ResponseWriter, r *dns.Msg) int {
	// DNS-over-TCP uses a 16-bit message length and can carry a substantially
	// larger transport block than UDP. The Android client reads this framing
	// with readUnsignedShort(), so start conservatively at 16 KiB of RDATA.
	if w != nil && w.RemoteAddr() != nil {
		network := strings.ToLower(w.RemoteAddr().Network())
		if strings.Contains(network, "tcp") {
			return serverResponseChunk
		}
	}

	// Actual UDP stays EDNS-aware. If the queued downstream block does not fit,
	// handleDownstreamResponse returns TC=1 and preserves the packets so a
	// recursive resolver can retry the same question over TCP.
	// The Android Mode 6 client sends direct UDP DNS queries without EDNS.
	// The measured mobile path supports a 1500-byte IPv4 MTU with DF; keep
	// conservative DNS/header headroom while avoiding needless TCP fallback.
	limit := 1350
	if edns := r.IsEdns0(); edns != nil {
		udpSize := int(edns.UDPSize())
		if udpSize >= 512 {
			limit = udpSize - 128
		}
	}
	if limit < 256 {
		limit = 256
	}
	return limit
}

func isTCPDNS(w dns.ResponseWriter) bool {
	if w == nil || w.RemoteAddr() == nil {
		return false
	}
	return strings.Contains(strings.ToLower(w.RemoteAddr().Network()), "tcp")
}

func recordSinglePacketTCSize(wanted int) {
	switch {
	case wanted <= 1380:
		atomic.AddUint64(&perfTC1351To1380, 1)
	case wanted <= 1400:
		atomic.AddUint64(&perfTC1381To1400, 1)
	case wanted <= 1450:
		atomic.AddUint64(&perfTC1401To1450, 1)
	default:
		atomic.AddUint64(&perfTC1451Plus, 1)
	}
}

func writeTruncatedResponse(w dns.ResponseWriter, r *dns.Msg, s *ClientSession, wanted int) {
	m := new(dns.Msg)
	m.SetReply(r)
	m.Truncated = true
	m.Compress = false
	atomic.AddUint64(&perfTCSent, 1)
	recordSinglePacketTCSize(wanted)
	_ = s
	if err := w.WriteMsg(m); err != nil {
		silentLogf("⚠️ truncated DNS response write failed: %v", err)
	}
}

func writeTransportResponse(w dns.ResponseWriter, r *dns.Msg, q dns.Question, data []byte) {
	m := new(dns.Msg)
	m.SetReply(r)
	m.Compress = false

	// Android l() treats exactly two bytes {'o','k'} as an ACK/no-data reply.
	if len(data) == 0 {
		data = []byte("ok")
		atomic.AddUint64(&perfOKResponses, 1)
	} else {
		atomic.AddUint64(&perfDataResponses, 1)
		atomic.AddUint64(&perfDownloadRDATABytes, uint64(len(data)))
	}

	limit := transportDataLimit(w, r)
	if len(data) > limit {
		silentLogf("⚠️ transport payload exceeds DNS limit | BYTES=%d | LIMIT=%d", len(data), limit)
		m.Rcode = dns.RcodeServerFailure
		_ = w.WriteMsg(m)
		return
	}

	rr := &dns.NULL{
		Hdr: dns.RR_Header{
			Name:   q.Name,
			Rrtype: dns.TypeNULL,
			Class:  dns.ClassINET,
			Ttl:    1,
		},
		Data: string(data),
	}
	m.Answer = append(m.Answer, rr)
	if err := w.WriteMsg(m); err != nil {
		silentLogf("⚠️ transport response write failed: %v", err)
	}
}

func handleDownstreamResponse(w dns.ResponseWriter, r *dns.Msg, q dns.Question, s *ClientSession) {
	touchSession(s)

	limit := transportDataLimit(w, r)
	tcp := isTCPDNS(w)
	if tcp {
		atomic.AddUint64(&perfTCPRetry, 1)
	}

	first, ok := takeNextDownstreamPacket(s)
	if !ok {
		writeTransportResponse(w, r, q, nil)
		return
	}

	packets := [][]byte{first}
	best, err := compressDownstreamPackets(packets)
	if err != nil {
		putPendingPacket(s, first)
		silentLogf("⚠️ downstream zlib compress failed | SID=%s | %v", s.SID, err)
		writeTransportResponse(w, r, q, nil)
		return
	}

	// If one complete packet cannot fit in UDP, preserve it and use the
	// protocol's existing TC->TCP retry path. This is the only normal reason
	// for UDP to request TCP; an oversized multi-packet batch no longer does so.
	if len(best)+28 > limit {
		putPendingPacket(s, first)
		if !tcp && len(best) <= serverResponseChunk {
			writeTruncatedResponse(w, r, s, len(best))
			return
		}
		silentLogf("⚠️ single downstream packet exceeds transport limit | SID=%s | BYTES=%d | LIMIT=%d", s.SID, len(best), limit)
		writeTransportResponse(w, r, q, nil)
		return
	}

	// Grow the batch only while the complete compressed stream still fits the
	// current transport. The first packet that would overflow is put back at
	// the front for the next query. This preserves Android framing and ordering
	// while avoiding unnecessary UDP TC fallbacks caused by over-batching.
	for len(packets) < maxDownstreamBatch {
		next, ok := takeNextDownstreamPacket(s)
		if !ok {
			break
		}

		candidatePackets := append(packets, next)
		candidate, err := compressDownstreamPackets(candidatePackets)
		if err != nil {
			putPendingPacket(s, next)
			silentLogf("⚠️ downstream zlib compress failed | SID=%s | %v", s.SID, err)
			break
		}

		if len(candidate)+28 > limit {
			putPendingPacket(s, next)
			break
		}

		packets = candidatePackets
		best = candidate
	}

	logStartupEvent(s, "FIRST_RDATA")
	s.cryptoMu.RLock()
	cryptoSession := s.crypto
	s.cryptoMu.RUnlock()
	if cryptoSession == nil { writeTransportResponse(w, r, q, nil); return }
	encrypted, err := cryptoSession.sealToClient(best)
	if err != nil { writeTransportResponse(w, r, q, nil); return }
	writeTransportResponse(w, r, q, encrypted)
}

// ------------------------------------------------------------
// DNS handler
// ------------------------------------------------------------

func handleDNSRequest(w dns.ResponseWriter, r *dns.Msg) {
	if len(r.Question) == 0 {
		m := new(dns.Msg)
		m.SetReply(r)
		m.Rcode = dns.RcodeFormatError
		_ = w.WriteMsg(m)
		return
	}

	q := r.Question[0]
	domain := strings.ToLower(strings.TrimSuffix(q.Name, "."))

	if strings.Contains(domain, "handshake") {
		silentLogf("🧪 RAW HANDSHAKE | FROM=%v | QNAME=%s | TYPE=%d",
			w.RemoteAddr(), q.Name, q.Qtype)
	}

	if strings.HasPrefix(domain, "0-handshake-v2.") {
		hwid, _, ok := parseHandshake(q.Name)
		if ok {
			silentLogf("🔎 Handshake detected | HWID=%s | QTYPE=%d", hwid, q.Qtype)
			handleHandshake(w, r, q)
			return
		}
	}

	sid, encoded, poll, ok := parseDataQuery(q.Name)
	if !ok {
		// Public UDP/TCP 53 receives constant Internet background scans.
		// Reply quietly so unrelated DNS traffic cannot flood syslog or steal CPU.
		m := new(dns.Msg)
		m.SetReply(r)
		m.Rcode = dns.RcodeNameError
		_ = w.WriteMsg(m)
		return
	}

	sess, ok := getSessionBySID(sid)
	if !ok {
		// The client already has a built-in recovery path for this exact payload.
		// Returning it in a successful NULL response makes an old/stale SID
		// immediately trigger a fresh handshake after server restart or session expiry.
		m := new(dns.Msg)
		m.SetReply(r)
		m.Compress = false
		writeNULLResponse(m, q, []byte("session-expired"))
		_ = w.WriteMsg(m)
		return
	}

	touchSession(sess)

	// Both DATA and POLL are QTYPE=10 in the analyzed client.
	if q.Qtype != dataQType {
		m := new(dns.Msg)
		m.SetReply(r)
		m.Rcode = dns.RcodeRefused
		_ = w.WriteMsg(m)
		return
	}

	if poll {
		atomic.AddUint64(&perfPollQueries, 1)
		//silentLogf("📥 POLL | SID=%s", sid)
		handleDownstreamResponse(w, r, q, sess)
		return
	}

	atomic.AddUint64(&perfDataQueries, 1)
	//silentLogf("📦 DNS DATA | SID=%s | encoded=%d chars", sid, len(encoded))
	source := "unknown"
	if w != nil && w.RemoteAddr() != nil {
		source = w.RemoteAddr().String()
	}
	handleClientData(sess, encoded, source)

	// Proven by client correlation logs:
	// DATA -> OK, DATA -> DATA, POLL -> OK and POLL -> DATA all occur.
	// Therefore every valid transport query is also an opportunity to return
	// queued downstream traffic.
	handleDownstreamResponse(w, r, q, sess)
}

type AdminClientView struct {
	HWID          string     `json:"hwid"`
	Status        HWIDStatus `json:"status"`
	Mode          int        `json:"mode"`
	Protocol      string     `json:"protocol"`
	FirstSeen     time.Time  `json:"first_seen"`
	LastSeen      time.Time  `json:"last_seen"`
	Connected     bool       `json:"connected"`
	IP            string     `json:"ip,omitempty"`
	SID           string     `json:"sid,omitempty"`
	UploadBytes   uint64     `json:"upload_bytes"`
	DownloadBytes uint64     `json:"download_bytes"`
	TotalBytes    uint64     `json:"total_bytes"`
}

type Mode7SessionView struct {
	HWID          string    `json:"hwid"`
	Mode          int       `json:"mode"`
	Protocol      string    `json:"protocol"`
	Connected     bool      `json:"connected"`
	IP            string    `json:"ip"`
	SID           string    `json:"sid"`
	CreatedAt     time.Time `json:"created_at"`
	LastSeen      time.Time `json:"last_seen"`
	UploadBytes   uint64    `json:"upload_bytes"`
	DownloadBytes uint64    `json:"download_bytes"`
	TotalBytes    uint64    `json:"total_bytes"`
}

type Mode7AuthorizeResponse struct {
	Allowed bool       `json:"allowed"`
	Status  HWIDStatus `json:"status"`
}

var mode7HTTPClient = &http.Client{Timeout: 1200 * time.Millisecond}

func fetchMode7Sessions() ([]Mode7SessionView, error) {
	resp, err := mode7HTTPClient.Get(mode7SessionsURL)
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()

	if resp.StatusCode != http.StatusOK {
		return nil, fmt.Errorf("Mode 7 API returned HTTP %d", resp.StatusCode)
	}

	var sessions []Mode7SessionView
	if err := json.NewDecoder(io.LimitReader(resp.Body, 2<<20)).Decode(&sessions); err != nil {
		return nil, err
	}
	return sessions, nil
}

func disconnectMode7Sessions(hwid string) {
	resp, err := mode7HTTPClient.PostForm(
		"http://127.0.0.1:8081/api/disconnect",
		url.Values{"hwid": {hwid}},
	)
	if err != nil {
		silentLogf("⚠️ Cannot disconnect Mode 7 session | HWID=%s | ERR=%v", hwid, err)
		return
	}
	_ = resp.Body.Close()
}

func adminAuthorizeMode7(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodGet {
		http.Error(w, "GET required", http.StatusMethodNotAllowed)
		return
	}

	hwid := strings.ToLower(strings.TrimSpace(r.URL.Query().Get("hwid")))
	if hwid == "" {
		http.Error(w, "missing hwid", http.StatusBadRequest)
		return
	}

	status := getHWIDStatus(hwid)
	w.Header().Set("Content-Type", "application/json; charset=utf-8")
	w.Header().Set("Cache-Control", "no-store")
	_ = json.NewEncoder(w).Encode(Mode7AuthorizeResponse{
		Allowed: status == StatusApproved,
		Status:  status,
	})
}

func disconnectSessionByHWID(hwid string) bool {
	hwid = strings.ToLower(strings.TrimSpace(hwid))

	sessionMu.Lock()
	s, ok := sessionByHWID[hwid]
	if ok {
		delete(sessionByHWID, hwid)
	}
	sessionMu.Unlock()

	if !ok || s == nil {
		return false
	}

	sessionsBySID.Delete(s.SID)
	sessionsByIP.Delete(s.IP)
	releaseClientIP(s.IP)

	log.Printf("🔌 SESSION ENDED | HWID=%s | SID=%s | IP=%s", s.HWID, s.SID, s.IP)
	return true
}

func adminClientsSnapshot() []AdminClientView {
	hwidMu.RLock()
	entries := make([]HWIDEntry, 0, len(hwidList))
	statusByHWID := make(map[string]HWIDStatus, len(hwidList))
	for _, e := range hwidList {
		entries = append(entries, *e)
		statusByHWID[e.HWID] = e.Status
	}
	hwidMu.RUnlock()

	now := time.Now()
	out := make([]AdminClientView, 0, len(entries)+8)

	sessionMu.Lock()
	for _, e := range entries {
		v := AdminClientView{
			HWID:          e.HWID,
			Status:        e.Status,
			Mode:          6,
			Protocol:      "SlowDNS",
			FirstSeen:     e.FirstSeen,
			LastSeen:      e.LastSeen,
			UploadBytes:   e.UploadBytes,
			DownloadBytes: e.DownloadBytes,
			TotalBytes:    e.UploadBytes + e.DownloadBytes,
		}

		if s, ok := sessionByHWID[e.HWID]; ok && s != nil {
			v.IP = s.IP
			v.SID = s.SID
			if !s.CreatedAt.IsZero() {
				v.FirstSeen = s.CreatedAt
			}
			// A session remains in memory after a client becomes idle, so define
			// "connected now" as recent transport activity.
			v.Connected = now.Sub(sessionLastSeen(s)) <= 30*time.Second
		}

		out = append(out, v)
	}
	sessionMu.Unlock()

	mode7Sessions, err := fetchMode7Sessions()
	if err != nil {
		return dedupeAdminClients(out)
	}

	for _, s := range mode7Sessions {
		hwid := strings.ToLower(strings.TrimSpace(s.HWID))
		if hwid == "" {
			continue
		}

		status, exists := statusByHWID[hwid]
		if !exists {
			status = StatusPending
		}

		firstSeen := s.CreatedAt
		if firstSeen.IsZero() {
			firstSeen = s.LastSeen
		}

		out = append(out, AdminClientView{
			HWID:          hwid,
			Status:        status,
			Mode:          7,
			Protocol:      "STUN-UDP",
			FirstSeen:     firstSeen,
			LastSeen:      s.LastSeen,
			Connected:     s.Connected,
			IP:            s.IP,
			SID:           s.SID,
			UploadBytes:   s.UploadBytes,
			DownloadBytes: s.DownloadBytes,
			TotalBytes:    s.TotalBytes,
		})
	}

	return dedupeAdminClients(out)
}

// The panel is device-centric: one HWID must occupy one row even when it has
// historical Mode 6 data and a current Mode 7 session. Prefer the connected
// (then most recently active) session for the visible mode/IP/SID and aggregate
// its traffic counters without duplicating the device row.
func dedupeAdminClients(rows []AdminClientView) []AdminClientView {
	out := make([]AdminClientView, 0, len(rows))
	indexByHWID := make(map[string]int, len(rows))

	for _, row := range rows {
		key := strings.ToLower(strings.TrimSpace(row.HWID))
		if key == "" {
			continue
		}
		row.HWID = key

		idx, exists := indexByHWID[key]
		if !exists {
			indexByHWID[key] = len(out)
			out = append(out, row)
			continue
		}

		current := out[idx]
		upload := current.UploadBytes + row.UploadBytes
		download := current.DownloadBytes + row.DownloadBytes
		preferRow := (row.Connected && !current.Connected) ||
			(row.Connected == current.Connected && row.LastSeen.After(current.LastSeen))

		if preferRow {
			row.UploadBytes = upload
			row.DownloadBytes = download
			row.TotalBytes = upload + download
			out[idx] = row
		} else {
			current.UploadBytes = upload
			current.DownloadBytes = download
			current.TotalBytes = upload + download
			out[idx] = current
		}
	}

	return out
}

func adminClientsJSON(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Content-Type", "application/json; charset=utf-8")
	w.Header().Set("Cache-Control", "no-store")
	_ = json.NewEncoder(w).Encode(adminClientsSnapshot())
}

func adminAction(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "POST required", http.StatusMethodNotAllowed)
		return
	}

	if err := r.ParseForm(); err != nil {
		http.Error(w, "invalid form", http.StatusBadRequest)
		return
	}

	hwid := strings.ToLower(strings.TrimSpace(r.FormValue("hwid")))
	action := strings.ToLower(strings.TrimSpace(r.FormValue("action")))
	if hwid == "" {
		http.Error(w, "missing hwid", http.StatusBadRequest)
		return
	}

	var status HWIDStatus
	disconnect := false

	switch action {
	case "approve":
		status = StatusApproved
	case "pending":
		status = StatusPending
		disconnect = true
	case "block":
		status = StatusDenied
		disconnect = true
	case "unblock":
		// Unblock returns the device to approval queue instead of silently
		// granting access.
		status = StatusPending
		disconnect = true
	case "revoke":
		status = StatusPending
		disconnect = true
	default:
		http.Error(w, "unknown action", http.StatusBadRequest)
		return
	}

	if err := setHWIDStatus(hwid, status); err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	if disconnect {
		disconnectSessionByHWID(hwid)
		disconnectMode7Sessions(hwid)
	}

	w.Header().Set("Content-Type", "application/json; charset=utf-8")
	_ = json.NewEncoder(w).Encode(map[string]any{
		"ok":     true,
		"hwid":   hwid,
		"status": status,
	})
}

const adminHTML = `<!doctype html>
<html lang="ar" dir="rtl">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>ABSO Client Manager</title>
<style>
:root{color-scheme:dark;background:#0b1020;color:#edf2ff;font-family:system-ui,-apple-system,Segoe UI,Tahoma,sans-serif}
*{box-sizing:border-box}body{margin:0;background:#0b1020}.wrap{max-width:1200px;margin:auto;padding:24px}
h1{font-size:24px;margin:0 0 6px}.sub{color:#9aa6c7;margin-bottom:22px}
.stats{display:grid;grid-template-columns:repeat(6,1fr);gap:12px;margin-bottom:18px}
.card{background:#121a31;border:1px solid #26304d;border-radius:14px;padding:16px}.num{font-size:28px;font-weight:800;margin-top:4px}
.addbox{display:flex;gap:10px;flex-wrap:wrap;align-items:center;background:#121a31;border:1px solid #26304d;border-radius:14px;padding:14px;margin:0 0 16px}
.addbox input,.addbox select{background:#0b1020;color:#edf2ff;border:1px solid #33405f;border-radius:9px;padding:10px 12px;min-height:40px}
.addbox input{direction:ltr;text-align:left;min-width:260px;flex:1}
.addbox button{background:#2f9e62;color:white;border:0;border-radius:9px;padding:10px 16px;cursor:pointer;font-weight:800}
.addmsg{font-size:13px;color:#9aa6c7;min-width:130px}
.authbox{display:flex;align-items:center;justify-content:space-between;gap:14px;flex-wrap:wrap;background:#121a31;border:1px solid #26304d;border-radius:14px;padding:14px 16px;margin:0 0 16px}
.authstate{display:flex;align-items:center;gap:10px}.authdot{width:11px;height:11px;border-radius:50%;background:#d28a22;box-shadow:0 0 12px rgba(210,138,34,.35)}
.authdot.on{background:#2fcb78;box-shadow:0 0 12px rgba(47,203,120,.45)}.authbox button{background:#17213c;color:#eaf0ff;border:1px solid #33405f;border-radius:10px;padding:10px 14px;cursor:pointer;font-weight:800}
.usage{direction:ltr;text-align:left;font-variant-numeric:tabular-nums}.usage small{display:block;margin-top:3px}
.toolbar{display:flex;gap:10px;flex-wrap:wrap;margin:15px 0}.searchsort{display:flex;gap:10px;flex-wrap:wrap;align-items:center;background:#121a31;border:1px solid #26304d;border-radius:14px;padding:14px;margin:0 0 16px}.searchsort input,.searchsort select{background:#0b1020;color:#edf2ff;border:1px solid #33405f;border-radius:9px;padding:10px 12px;min-height:40px}.searchsort input{direction:ltr;text-align:left;min-width:250px;flex:1}.restart{background:#b83245!important;color:#fff!important;border-color:#d95869!important}.toolbar{display:flex;gap:10px;flex-wrap:wrap;margin:15px 0}.toolbar button,.tab{background:#17213c;color:#eaf0ff;border:1px solid #33405f;border-radius:10px;padding:10px 13px;cursor:pointer}
.tab.active{background:#2a3c72}.table{overflow:auto;border:1px solid #26304d;border-radius:14px}
table{width:100%;border-collapse:collapse;background:#11182d}th,td{padding:12px;border-bottom:1px solid #222c46;text-align:right;white-space:nowrap}
th{color:#aeb9d7;font-size:13px}.badge{padding:5px 9px;border-radius:999px;font-size:12px;font-weight:700}
.pending{background:#493d16;color:#ffe08a}.approved{background:#153d2d;color:#89f0bc}.denied{background:#4a1f29;color:#ff9bad}.online{background:#15364a;color:#91d8ff}.offline{background:#252c40;color:#aab3ca}
.mode6{background:#34285b;color:#cbbcff}.mode7{background:#12483f;color:#83f1d2}
.actions{display:flex;gap:6px}.actions button{border:0;border-radius:8px;padding:7px 10px;cursor:pointer;font-weight:700}
.approve{background:#2f9e62;color:white}.block{background:#c74659;color:white}.unblock{background:#d28a22;color:white}.revoke{background:#56617b;color:white}
small{color:#96a2c0}.empty{text-align:center;padding:30px;color:#96a2c0}
@media(max-width:1000px){.stats{grid-template-columns:repeat(3,1fr)}}
@media(max-width:760px){.stats{grid-template-columns:repeat(2,1fr)}.wrap{padding:14px}}

.logpanel{display:none;margin-top:18px;background:#0a0f1c;border:1px solid #26304d;border-radius:14px;overflow:hidden}
.loghead{display:flex;align-items:center;justify-content:space-between;gap:10px;padding:12px 14px;background:#121a31;border-bottom:1px solid #26304d}
.logtitle{font-weight:800}
.logcontrols{display:flex;gap:8px;flex-wrap:wrap}
.logcontrols button{background:#17213c;color:#eaf0ff;border:1px solid #33405f;border-radius:8px;padding:7px 10px;cursor:pointer}
.logview{direction:ltr;text-align:left;white-space:pre-wrap;word-break:break-word;overflow:auto;height:420px;margin:0;padding:14px;background:#050914;color:#d9e3ff;font:13px/1.5 Consolas,Monaco,monospace}
</style>
</head>
<body>
<div class="wrap">
<h1>إدارة عملاء ABSO</h1>
<div class="sub">تحديث تلقائي كل ثانيتين — الواجهة مربوطة على localhost فقط</div>

<div class="stats">
 <div class="card">متصل الآن<div class="num" id="s-online">0</div></div>
 <div class="card">Mode 6<div class="num" id="s-mode6">0</div></div>
 <div class="card">Mode 7<div class="num" id="s-mode7">0</div></div>
 <div class="card">في الانتظار<div class="num" id="s-pending">0</div></div>
 <div class="card">مفعّل<div class="num" id="s-approved">0</div></div>
 <div class="card">محظور<div class="num" id="s-blocked">0</div></div>
 <div class="card">إجمالي الرفع<div class="num" id="s-upload">0 B</div></div>
 <div class="card">إجمالي التنزيل<div class="num" id="s-download">0 B</div></div>
 <div class="card">إجمالي البيانات<div class="num" id="s-total">0 B</div></div>
</div>

<div class="authbox">
 <div>
  <div class="authstate"><span id="authDot" class="authdot"></span><strong id="authTitle">التفويض اليدوي</strong></div>
  <small id="authDesc">الأجهزة الجديدة تدخل في الانتظار حتى يتم تفعيلها من اللوحة.</small>
 </div>
 <button id="authToggleBtn" onclick="toggleAuthMode()">تفعيل الدخول التلقائي</button>
</div>

<div class="addbox">
 <input id="manualHwid" type="text" placeholder="HWID مثال: da757adcd7469799" autocomplete="off">
 <select id="manualStatus">
   <option value="approve">مفعّل</option>
   <option value="pending">في الانتظار</option>
   <option value="block">محظور</option>
 </select>
 <button onclick="addManualHwid()">➕ إضافة / تحديث</button>
 <span id="addMsg" class="addmsg"></span>
</div>

<div class="searchsort">
 <input id="searchHwid" type="search" placeholder="بحث عن HWID..." autocomplete="off">
 <select id="sortField">
   <option value="total">الاستهلاك الكلي</option>
   <option value="download">التنزيل</option>
   <option value="upload">الرفع</option>
   <option value="hwid">HWID</option>
 </select>
 <select id="sortDir">
   <option value="desc">الأكبر ← الأصغر</option>
   <option value="asc">الأصغر ← الأكبر</option>
 </select>
 <button class="restart" onclick="restartServer()">⟳ Restart Mode 6</button>
</div>

<div class="toolbar">
 <button class="tab active" data-filter="all">الكل</button>
 <button class="tab" data-filter="online">المتصلون</button>
 <button class="tab" data-filter="mode6">Mode 6</button>
 <button class="tab" data-filter="mode7">Mode 7</button>
 <button class="tab" data-filter="pending">في الانتظار</button>
 <button class="tab" data-filter="approved">المفعّلون</button>
 <button class="tab" data-filter="denied">المحظورون</button>
 <button onclick="loadClients()">تحديث الآن</button>
 <button id="logsBtn" onclick="toggleLogs()">📜 Logs</button>
</div>

<div class="table">
<table>
<thead><tr>
<th>HWID</th><th>المود</th><th>الحالة</th><th>الاتصال</th><th>استهلاك البيانات</th><th>IP</th><th>SID</th><th>مدة الاتصال / آخر نشاط</th><th>العمليات</th>
</tr></thead>
<tbody id="rows"></tbody>
</table>
<div id="empty" class="empty" style="display:none">لا توجد أجهزة في هذا القسم</div>
</div>

<div id="logPanel" class="logpanel">
  <div class="loghead">
    <div class="logtitle">📜 Mode 6 + Mode 7 Live Log</div>
    <div class="logcontrols">
      <button onclick="loadLogs(true)">تحديث</button>
      <button id="autoBtn" onclick="toggleAutoLogs()">Auto: ON</button>
      <button onclick="clearLogView()">مسح العرض</button>
      <button onclick="toggleLogs()">إغلاق</button>
    </div>
  </div>
  <pre id="logView" class="logview">اضغط Logs لعرض سجل خدمتي abso وstunudp...</pre>
</div>
</div>

<script>
let clients=[], filter='all', searchTerm='', sortField='total', sortDir='desc';

function esc(v){return String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
function age(iso){
 if(!iso)return '-';
 const sec=Math.max(0,Math.floor((Date.now()-new Date(iso).getTime())/1000));
 if(sec<60)return sec+' ث';
 if(sec<3600)return Math.floor(sec/60)+' د';
 if(sec<86400)return Math.floor(sec/3600)+' س';
 return Math.floor(sec/86400)+' ي';
}
function connectionAge(c){
 if(c.connected){
   return '<strong>'+age(c.first_seen)+'</strong><small>آخر نشاط: '+age(c.last_seen)+'</small>';
 }
 return '<strong>غير متصل</strong><small>آخر ظهور: '+age(c.last_seen)+'</small>';
}
function statusName(s){return s==='approved'?'مفعّل':s==='pending'?'في الانتظار':'محظور'}
function fmtBytes(n){
 n=Number(n||0);
 if(n<1024)return n+' B';
 const u=['KB','MB','GB','TB']; let i=-1;
 do{n/=1024;i++;}while(n>=1024 && i<u.length-1);
 return n.toFixed(n>=100?0:n>=10?1:2)+' '+u[i];
}
function buttons(c){
 if(c.status==='pending') return '<button class="approve" onclick="act(\''+c.hwid+'\',\'approve\')">تفعيل</button><button class="block" onclick="act(\''+c.hwid+'\',\'block\')">حظر</button>';
 if(c.status==='approved') return '<button class="revoke" onclick="act(\''+c.hwid+'\',\'revoke\')">إلغاء التفعيل</button><button class="block" onclick="act(\''+c.hwid+'\',\'block\')">حظر</button>';
 return '<button class="unblock" onclick="act(\''+c.hwid+'\',\'unblock\')">فك الحظر</button><button class="approve" onclick="act(\''+c.hwid+'\',\'approve\')">تفعيل مباشر</button>';
}
function render(){
 document.getElementById('s-online').textContent=clients.filter(x=>x.connected).length;
 document.getElementById('s-mode6').textContent=clients.filter(x=>x.connected&&x.mode===6).length;
 document.getElementById('s-mode7').textContent=clients.filter(x=>x.connected&&x.mode===7).length;
 const devices=[...new Map(clients.map(x=>[x.hwid,x])).values()];
 document.getElementById('s-pending').textContent=devices.filter(x=>x.status==='pending').length;
 document.getElementById('s-approved').textContent=devices.filter(x=>x.status==='approved').length;
 document.getElementById('s-blocked').textContent=devices.filter(x=>x.status==='denied').length;
 // Mode 6 counters are persisted per HWID. Mode 7 rows are separate live sessions,
 // so sum the API rows exactly as displayed and avoid inventing cross-mode persistence.
 const totalUp=clients.reduce((a,x)=>a+Number(x.upload_bytes||0),0);
 const totalDown=clients.reduce((a,x)=>a+Number(x.download_bytes||0),0);
 document.getElementById('s-upload').textContent=fmtBytes(totalUp);
 document.getElementById('s-download').textContent=fmtBytes(totalDown);
 document.getElementById('s-total').textContent=fmtBytes(totalUp+totalDown);

 let list=clients.slice();
 if(filter==='online') list=list.filter(x=>x.connected);
 else if(filter==='mode6') list=list.filter(x=>x.mode===6);
 else if(filter==='mode7') list=list.filter(x=>x.mode===7);
 else if(filter!=='all') list=list.filter(x=>x.status===filter);

 if(searchTerm) list=list.filter(x=>String(x.hwid||'').toLowerCase().includes(searchTerm));
 list.sort((a,b)=>{
   let av,bv;
   if(sortField==='hwid'){ av=String(a.hwid||''); bv=String(b.hwid||''); return sortDir==='asc'?av.localeCompare(bv):bv.localeCompare(av); }
   if(sortField==='upload'){av=Number(a.upload_bytes||0);bv=Number(b.upload_bytes||0);}
   else if(sortField==='download'){av=Number(a.download_bytes||0);bv=Number(b.download_bytes||0);}
   else {av=Number(a.total_bytes||0);bv=Number(b.total_bytes||0);}
   return sortDir==='asc'?av-bv:bv-av;
 });

 const rows=document.getElementById('rows');
 rows.innerHTML=list.map(c=>'<tr>' +
 '<td><code>'+esc(c.hwid)+'</code></td>' +
 '<td><span class="badge mode'+esc(c.mode)+'">Mode '+esc(c.mode)+' · '+esc(c.protocol)+'</span></td>' +
 '<td><span class="badge '+esc(c.status)+'">'+statusName(c.status)+'</span></td>' +
 '<td><span class="badge '+(c.connected?'online':'offline')+'">'+(c.connected?'متصل':'غير متصل')+'</span></td>' +
 '<td class="usage"><strong>'+fmtBytes(c.total_bytes)+'</strong><small>↑ '+fmtBytes(c.upload_bytes)+' &nbsp; ↓ '+fmtBytes(c.download_bytes)+'</small></td>' +
 '<td>'+esc(c.ip||'-')+'</td>' +
 '<td><code>'+esc(c.sid||'-')+'</code></td>' +
 '<td class="usage" title="بداية الاتصال: '+esc(c.first_seen)+' | آخر نشاط: '+esc(c.last_seen)+'">'+connectionAge(c)+'</td>' +
 '<td><div class="actions">'+buttons(c)+'</div></td>' +
 '</tr>').join('');
 document.getElementById('empty').style.display=list.length?'none':'block';
}
async function loadClients(){
 try{
   const r=await fetch('/api/clients',{cache:'no-store'});
   clients=await r.json();
   render();
 }catch(e){}
}

async function addManualHwid(){
 const input=document.getElementById('manualHwid');
 const status=document.getElementById('manualStatus').value;
 const msg=document.getElementById('addMsg');
 const hwid=input.value.trim().toLowerCase();

 if(!hwid){
   msg.textContent='أدخل HWID';
   return;
 }
 if(hwid.length<4 || hwid.length>128 || !/^[a-z0-9._:-]+$/.test(hwid)){
   msg.textContent='HWID غير صالح';
   return;
 }

 msg.textContent='جاري الحفظ...';
 try{
   const body=new URLSearchParams({hwid,action:status});
   const r=await fetch('/api/action',{
     method:'POST',
     headers:{'Content-Type':'application/x-www-form-urlencoded'},
     body
   });
   if(!r.ok){
     msg.textContent='خطأ: '+await r.text();
     return;
   }

   input.value='';
   msg.textContent='تم الحفظ ✓';
   await loadClients();
   setTimeout(()=>{ if(msg.textContent==='تم الحفظ ✓') msg.textContent=''; },2500);
 }catch(e){
   msg.textContent='تعذر الاتصال';
 }
}

async function act(hwid,action){
 const body=new URLSearchParams({hwid,action});
 const r=await fetch('/api/action',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body});
 if(!r.ok){alert(await r.text());return}
 await loadClients();
}
document.querySelectorAll('.tab').forEach(b=>b.onclick=()=>{
 document.querySelectorAll('.tab').forEach(x=>x.classList.remove('active'));
 b.classList.add('active'); filter=b.dataset.filter; render();
});

let autoApprove=false;

function renderAuthMode(){
 const dot=document.getElementById('authDot');
 const title=document.getElementById('authTitle');
 const desc=document.getElementById('authDesc');
 const btn=document.getElementById('authToggleBtn');
 dot.classList.toggle('on',autoApprove);
 title.textContent=autoApprove?'الدخول التلقائي مفعّل':'التفويض اليدوي';
 desc.textContent=autoApprove
   ?'أي جهاز جديد أو في الانتظار يتم تفعيله تلقائياً عند محاولة الاتصال. الأجهزة المحظورة تبقى محظورة.'
   :'الأجهزة الجديدة تدخل في الانتظار حتى يتم تفعيلها من اللوحة.';
 btn.textContent=autoApprove?'إيقاف الدخول التلقائي':'تفعيل الدخول التلقائي';
}

async function loadAuthMode(){
 try{
   const r=await fetch('/api/auth-mode',{cache:'no-store'});
   const j=await r.json();
   autoApprove=!!j.auto_approve;
   renderAuthMode();
 }catch(e){}
}

async function toggleAuthMode(){
 const next=!autoApprove;
 const body=new URLSearchParams({enabled:next?'true':'false'});
 try{
   const r=await fetch('/api/auth-mode',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body});
   if(!r.ok){alert(await r.text());return}
   const j=await r.json();
   autoApprove=!!j.auto_approve;
   renderAuthMode();
   await loadClients();
 }catch(e){alert('تعذر تغيير وضع التفويض')}
}

let logsOpen=false;
let autoLogs=true;
let logTimer=null;

async function loadLogs(scrollBottom=false){
  if(!logsOpen) return;
  try{
    const r=await fetch('/api/logs',{cache:'no-store'});
    const t=await r.text();
    const v=document.getElementById('logView');
    const wasNearBottom=(v.scrollHeight-v.scrollTop-v.clientHeight)<80;
    v.textContent=t || '(no logs)';
    if(scrollBottom || wasNearBottom) v.scrollTop=v.scrollHeight;
  }catch(e){
    document.getElementById('logView').textContent='Failed to load logs: '+e;
  }
}

function toggleLogs(){
  logsOpen=!logsOpen;
  const p=document.getElementById('logPanel');
  p.style.display=logsOpen?'block':'none';
  document.getElementById('logsBtn').textContent=logsOpen?'📜 إخفاء Logs':'📜 Logs';

  if(logsOpen){
    loadLogs(true);
    if(autoLogs && !logTimer){
      logTimer=setInterval(()=>loadLogs(false),2000);
    }
  }else if(logTimer){
    clearInterval(logTimer);
    logTimer=null;
  }
}

function toggleAutoLogs(){
  autoLogs=!autoLogs;
  document.getElementById('autoBtn').textContent='Auto: '+(autoLogs?'ON':'OFF');

  if(autoLogs && logsOpen && !logTimer){
    logTimer=setInterval(()=>loadLogs(false),2000);
  }else if(!autoLogs && logTimer){
    clearInterval(logTimer);
    logTimer=null;
  }
}

function clearLogView(){
  document.getElementById('logView').textContent='';
}


document.getElementById('searchHwid').addEventListener('input',e=>{searchTerm=e.target.value.trim().toLowerCase();render();});
document.getElementById('sortField').addEventListener('change',e=>{sortField=e.target.value;render();});
document.getElementById('sortDir').addEventListener('change',e=>{sortDir=e.target.value;render();});

async function restartServer(){
 if(!confirm('إعادة تشغيل خدمة Mode 6 (abso)؟\nسيتم فصل عملاء Mode 6 مؤقتاً ثم يعاودون الاتصال.')) return;
 try{
   const r=await fetch('/api/restart',{method:'POST'});
   if(!r.ok){alert('فشل طلب إعادة التشغيل: '+await r.text());return;}
   alert('تم قبول طلب إعادة التشغيل. ستعود الخدمة خلال ثوانٍ.');
 }catch(e){
   // The connection can close while systemd replaces this process; that can be normal.
   alert('تم إرسال طلب إعادة التشغيل؛ قد ينقطع اتصال اللوحة لثوانٍ.');
 }
}

document.getElementById('manualHwid').addEventListener('keydown',e=>{
 if(e.key==='Enter') addManualHwid();
});

loadClients(); setInterval(loadClients,2000);
loadAuthMode(); setInterval(loadAuthMode,5000);
</script>
</body>
</html>`

func adminAuthMode(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Content-Type", "application/json; charset=utf-8")
	w.Header().Set("Cache-Control", "no-store")

	switch r.Method {
	case http.MethodGet:
		_ = json.NewEncoder(w).Encode(map[string]any{
			"auto_approve": isAutoApproveEnabled(),
		})
		return

	case http.MethodPost:
		if err := r.ParseForm(); err != nil {
			http.Error(w, "invalid form", http.StatusBadRequest)
			return
		}
		raw := strings.ToLower(strings.TrimSpace(r.FormValue("enabled")))
		var enabled bool
		switch raw {
		case "1", "true", "on", "yes":
			enabled = true
		case "0", "false", "off", "no":
			enabled = false
		default:
			http.Error(w, "invalid enabled value", http.StatusBadRequest)
			return
		}

		if err := setAutoApprove(enabled); err != nil {
			http.Error(w, err.Error(), http.StatusInternalServerError)
			return
		}
		_ = json.NewEncoder(w).Encode(map[string]any{
			"ok":           true,
			"auto_approve": enabled,
		})
		return
	default:
		http.Error(w, "GET or POST required", http.StatusMethodNotAllowed)
	}
}

func adminLogs(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Content-Type", "text/plain; charset=utf-8")
	w.Header().Set("Cache-Control", "no-store")

	cmd := exec.Command(
		"journalctl",
		"-u", "abso",
		"-u", "stunudp",
		"-n", "250",
		"--no-pager",
		"-o", "short-iso",
	)

	out, err := cmd.CombinedOutput()
	if err != nil {
		http.Error(w, "cannot read VPN journals: "+err.Error(), http.StatusInternalServerError)
		return
	}

	_, _ = w.Write(out)
}

func adminRestart(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "POST required", http.StatusMethodNotAllowed)
		return
	}

	w.Header().Set("Content-Type", "application/json; charset=utf-8")
	w.Header().Set("Cache-Control", "no-store")
	_ = json.NewEncoder(w).Encode(map[string]any{"ok": true, "message": "restart scheduled"})

	// Give net/http a moment to flush the response before systemd stops this process.
	go func() {
		time.Sleep(350 * time.Millisecond)
		cmd := exec.Command("systemctl", "restart", "abso.service")
		if err := cmd.Start(); err != nil {
			silentLogf("❌ Cannot restart abso.service: %v", err)
		}
	}()
}

func adminPage(w http.ResponseWriter, r *http.Request) {
	if r.URL.Path != "/" {
		http.NotFound(w, r)
		return
	}
	w.Header().Set("Content-Type", "text/html; charset=utf-8")
	w.Header().Set("Cache-Control", "no-store")
	_, _ = io.WriteString(w, adminHTML)
}

// ------------------------------------------------------------
// Admin API
// ------------------------------------------------------------

func adminList(w http.ResponseWriter, r *http.Request) {
	hwidMu.RLock()
	entries := make([]HWIDEntry, 0, len(hwidList))
	for _, e := range hwidList {
		entries = append(entries, *e)
	}
	hwidMu.RUnlock()

	w.Header().Set("Content-Type", "application/json")
	_ = json.NewEncoder(w).Encode(entries)
}

func adminSetStatus(w http.ResponseWriter, r *http.Request, status HWIDStatus) {
	hwid := r.URL.Query().Get("hwid")
	if hwid == "" {
		http.Error(w, "missing hwid", http.StatusBadRequest)
		return
	}

	if err := setHWIDStatus(hwid, status); err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	fmt.Fprintf(w, "HWID %s -> %s\n", hwid, status)
}

func requireAdminAuth(next http.Handler) http.Handler {
	user := os.Getenv("MNR_PANEL_USER")
	passwordB64 := os.Getenv("MNR_PANEL_PASSWORD_B64")
	passwordBytes, err := base64.StdEncoding.DecodeString(passwordB64)
	if user == "" || err != nil || len(passwordBytes) == 0 {
		log.Fatal("panel authentication is not configured")
	}
	expectedUser := sha256.Sum256([]byte(user))
	expectedPassword := sha256.Sum256(passwordBytes)
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		providedUser, providedPassword, ok := r.BasicAuth()
		providedUserHash := sha256.Sum256([]byte(providedUser))
		providedPasswordHash := sha256.Sum256([]byte(providedPassword))
		valid := subtle.ConstantTimeCompare(expectedUser[:], providedUserHash[:]) &
			subtle.ConstantTimeCompare(expectedPassword[:], providedPasswordHash[:])
		if !ok || valid != 1 {
			w.Header().Set("WWW-Authenticate", `Basic realm="MNR Admin", charset="UTF-8"`)
			http.Error(w, "Authentication required", http.StatusUnauthorized)
			return
		}
		next.ServeHTTP(w, r)
	})
}

func loopbackOnly(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		host, _, err := net.SplitHostPort(r.RemoteAddr)
		ip := net.ParseIP(host)
		if err != nil || ip == nil || !ip.IsLoopback() {
			http.Error(w, "Forbidden", http.StatusForbidden)
			return
		}
		next.ServeHTTP(w, r)
	})
}

func startAdminServer() {
	protected := http.NewServeMux()

	// Web dashboard + JSON API.
	protected.HandleFunc("/", adminPage)
	protected.HandleFunc("/api/clients", adminClientsJSON)
	protected.HandleFunc("/api/action", adminAction)
	protected.HandleFunc("/api/auth-mode", adminAuthMode)
	protected.HandleFunc("/api/logs", adminLogs)
	protected.HandleFunc("/api/restart", adminRestart)

	// Keep the original endpoints for curl/backward compatibility.
	protected.HandleFunc("/hwids", adminList)
	protected.HandleFunc("/approve", func(w http.ResponseWriter, r *http.Request) {
		adminSetStatus(w, r, StatusApproved)
	})
	protected.HandleFunc("/deny", func(w http.ResponseWriter, r *http.Request) {
		adminSetStatus(w, r, StatusDenied)
		if hwid := r.URL.Query().Get("hwid"); hwid != "" {
			disconnectSessionByHWID(hwid)
		}
	})
	protected.HandleFunc("/pending", func(w http.ResponseWriter, r *http.Request) {
		hwidMu.RLock()
		defer hwidMu.RUnlock()

		for _, e := range hwidList {
			if e.Status == StatusPending {
				fmt.Fprintf(w, "%s  %s\n", e.HWID, e.LastSeen.Format(time.RFC3339))
			}
		}
	})

	// Mode 7 authorization is server-to-server only and must never be exposed
	// through the public panel address.
	root := http.NewServeMux()
	root.Handle("/api/internal/mode7-authorize", loopbackOnly(http.HandlerFunc(adminAuthorizeMode7)))
	root.Handle("/", requireAdminAuth(protected))

	silentLogf("🔐 Admin UI/API listening on %s", adminAddr)
	server := &http.Server{
		Addr:              adminAddr,
		Handler:           root,
		ReadHeaderTimeout: 10 * time.Second,
		IdleTimeout:       60 * time.Second,
	}
	log.Fatal(server.ListenAndServe())
}

// ------------------------------------------------------------
// main
// ------------------------------------------------------------

func main() {
	if err := loadServerIdentity(); err != nil {
		log.Fatalf("crypto identity: %v", err)
	}
	mustRoot()

	silentLogln("🚀 Starting NEW SlowDNS Server")
	silentLogf("🌐 Domain: %s", serverSuffix)

	cleanupOldVPNState()

	if err := loadHWIDs(); err != nil {
		log.Fatalf("❌ Cannot load %s: %v", hwidFile, err)
	}
	silentLogf("📋 Loaded %d HWIDs", len(hwidList))

	if err := loadAuthConfig(); err != nil {
		silentLogf("⚠️ Cannot load %s, using manual approval: %v", authConfigFile, err)
	}
	silentLogf("🔐 Authorization mode | auto_approve=%v", isAutoApproveEnabled())

	var err error
	tunIf, err = setupTunInterface()
	if err != nil {
		log.Fatalf("❌ TUN setup failed: %v", err)
	}

	if err := enableForwardingAndNAT(); err != nil {
		log.Fatalf("❌ Network forwarding/NAT setup failed: %v", err)
	}

	go usageSaver()
	go sessionCleaner()
	go tunReader()

	dns.HandleFunc(".", handleDNSRequest)

	go func() {
		server := &dns.Server{
			Addr: dnsPort,
			Net:  "udp",
		}
		silentLogf("🌐 DNS UDP listening on %s", dnsPort)
		if err := server.ListenAndServe(); err != nil {
			silentLogf("❌ DNS UDP stopped: %v", err)
		}
	}()

	go func() {
		server := &dns.Server{
			Addr: dnsPort,
			Net:  "tcp",
		}
		silentLogf("🌐 DNS TCP listening on %s", dnsPort)
		if err := server.ListenAndServe(); err != nil {
			silentLogf("❌ DNS TCP stopped: %v", err)
		}
	}()

	startAdminServer()
}
