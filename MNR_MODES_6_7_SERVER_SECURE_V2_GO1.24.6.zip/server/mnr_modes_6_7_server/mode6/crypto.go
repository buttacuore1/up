package main

import (
	"crypto/aes"
	"crypto/cipher"
	"crypto/ecdh"
	"crypto/ecdsa"
	"crypto/hmac"
	"crypto/rand"
	"crypto/sha256"
	"crypto/x509"
	"encoding/binary"
	"encoding/pem"
	"errors"
	"fmt"
	"os"
	"sync"
)

const identityPath = "/etc/mnr/crypto_identity.pem"

var serverIdentity *ecdh.PrivateKey

type handshakeCrypto struct {
	mode      byte
	clientPub []byte
	shared    []byte
	key       []byte
}

type tunnelCrypto struct {
	mode byte
	sid  string
	c2sKey, s2cKey       []byte
	c2sPrefix, s2cPrefix []byte
	sendMu sync.Mutex
	sendSeq uint64
	recvMu sync.Mutex
	recvHigh uint64
	recvInit bool
	recvWindow uint64
}

func loadServerIdentity() error {
	b, err := os.ReadFile(identityPath)
	if err != nil { return err }
	block, _ := pem.Decode(b)
	if block == nil { return errors.New("invalid crypto identity PEM") }
	parsed, err := x509.ParsePKCS8PrivateKey(block.Bytes)
	if err != nil { return err }
	ecdsaKey, ok := parsed.(*ecdsa.PrivateKey)
	if !ok { return errors.New("crypto identity is not EC P-256") }
	ec, err := ecdsaKey.ECDH()
	if err != nil { return err }
	serverIdentity = ec
	return nil
}

func newHandshakeCrypto(mode byte, clientPub []byte) (*handshakeCrypto, error) {
	if serverIdentity == nil { return nil, errors.New("server crypto identity unavailable") }
	pub, err := ecdh.P256().NewPublicKey(clientPub)
	if err != nil { return nil, err }
	shared, err := serverIdentity.ECDH(pub)
	if err != nil { return nil, err }
	saltInput := append([]byte("MNR-HS-SALT-V2|"), mode)
	saltInput = append(saltInput, clientPub...)
	salt := sha256.Sum256(saltInput)
	return &handshakeCrypto{mode: mode, clientPub: append([]byte(nil), clientPub...), shared: shared,
		key: hkdfSHA256(shared, salt[:], []byte("MNR-HANDSHAKE-V2"), 32)}, nil
}

func (h *handshakeCrypto) aad() []byte {
	a := append([]byte("MNR-HS-V2|"), h.mode)
	return append(a, h.clientPub...)
}

func (h *handshakeCrypto) seal(plain []byte) ([]byte, error) {
	block, err := aes.NewCipher(h.key); if err != nil { return nil, err }
	gcm, err := cipher.NewGCM(block); if err != nil { return nil, err }
	nonce := make([]byte, gcm.NonceSize()); if _, err = rand.Read(nonce); err != nil { return nil, err }
	return append(nonce, gcm.Seal(nil, nonce, plain, h.aad())...), nil
}

func (h *handshakeCrypto) open(envelope []byte) ([]byte, error) {
	block, err := aes.NewCipher(h.key); if err != nil { return nil, err }
	gcm, err := cipher.NewGCM(block); if err != nil { return nil, err }
	if len(envelope) < gcm.NonceSize()+gcm.Overhead() { return nil, errors.New("short handshake envelope") }
	return gcm.Open(nil, envelope[:gcm.NonceSize()], envelope[gcm.NonceSize():], h.aad())
}

func (h *handshakeCrypto) session(sid string) *tunnelCrypto {
	salt := sha256.Sum256([]byte(fmt.Sprintf("MNR-DATA-SALT-V2|%d|%s", h.mode, sid)))
	m := hkdfSHA256(h.shared, salt[:], []byte("MNR-E2EE-DATA-V2"), 72)
	return &tunnelCrypto{mode: h.mode, sid: sid, c2sKey: m[:32], s2cKey: m[32:64],
		c2sPrefix: m[64:68], s2cPrefix: m[68:72]}
}

func (t *tunnelCrypto) aad(direction byte, header []byte) []byte {
	a := []byte(fmt.Sprintf("MNR-DATA-V2|%d|%s|", t.mode, t.sid))
	a = append(a, direction)
	return append(a, header...)
}

func makeNonce(prefix []byte, seq uint64) []byte {
	n := make([]byte, 12); copy(n, prefix); binary.BigEndian.PutUint64(n[4:], seq); return n
}

func (t *tunnelCrypto) sealToClient(plain []byte) ([]byte, error) {
	t.sendMu.Lock(); seq := t.sendSeq; t.sendSeq++; t.sendMu.Unlock()
	header := make([]byte, 12); header[0]='M'; header[1]='2'; header[2]=1; header[3]=2
	binary.BigEndian.PutUint64(header[4:], seq)
	block, err := aes.NewCipher(t.s2cKey); if err != nil { return nil, err }
	gcm, err := cipher.NewGCM(block); if err != nil { return nil, err }
	return append(header, gcm.Seal(nil, makeNonce(t.s2cPrefix, seq), plain, t.aad(2, header))...), nil
}

func (t *tunnelCrypto) openFromClient(envelope []byte) ([]byte, error) {
	if len(envelope) < 29 || envelope[0]!='M' || envelope[1]!='2' || envelope[2]!=1 || envelope[3]!=1 {
		return nil, errors.New("invalid encrypted data envelope")
	}
	seq := binary.BigEndian.Uint64(envelope[4:12])
	t.recvMu.Lock(); defer t.recvMu.Unlock()
	if t.replayed(seq) { return nil, errors.New("replayed encrypted packet") }
	block, err := aes.NewCipher(t.c2sKey); if err != nil { return nil, err }
	gcm, err := cipher.NewGCM(block); if err != nil { return nil, err }
	plain, err := gcm.Open(nil, makeNonce(t.c2sPrefix, seq), envelope[12:], t.aad(1, envelope[:12]))
	if err != nil { return nil, err }
	t.accept(seq); return plain, nil
}

func (t *tunnelCrypto) replayed(seq uint64) bool {
	if !t.recvInit || seq > t.recvHigh { return false }
	d := t.recvHigh-seq; return d >= 64 || ((t.recvWindow>>d)&1)!=0
}
func (t *tunnelCrypto) accept(seq uint64) {
	if !t.recvInit { t.recvInit=true; t.recvHigh=seq; t.recvWindow=1; return }
	if seq > t.recvHigh { d:=seq-t.recvHigh; if d>=64 { t.recvWindow=1 } else { t.recvWindow=(t.recvWindow<<d)|1 }; t.recvHigh=seq
	} else { t.recvWindow |= uint64(1)<<(t.recvHigh-seq) }
}

func hkdfSHA256(ikm, salt, info []byte, length int) []byte {
	extract:=hmac.New(sha256.New,salt); extract.Write(ikm); prk:=extract.Sum(nil)
	out:=make([]byte,0,length); var prev []byte
	for counter:=byte(1); len(out)<length; counter++ { m:=hmac.New(sha256.New,prk); m.Write(prev); m.Write(info); m.Write([]byte{counter}); prev=m.Sum(nil); need:=length-len(out); if need>len(prev){need=len(prev)}; out=append(out,prev[:need]...) }
	return out
}
