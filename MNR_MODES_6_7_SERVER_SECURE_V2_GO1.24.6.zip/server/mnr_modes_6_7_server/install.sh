#!/usr/bin/env bash
set -Eeuo pipefail

ROOT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
MODE6_DIR="/root/abso"
MODE7_DIR="/root/stunudp"
STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
BUILD_DIR="$(mktemp -d /root/mnr-build.XXXXXX)"
GO_REQUIRED="1.24.6"
GO_AMD64_SHA256="bbca37cc395c974ffa4893ee35819ad23ebb27426df87af92e93a9ec66ef8712"

cleanup() {
  rm -rf "$BUILD_DIR"
}
trap cleanup EXIT

if [[ $EUID -ne 0 ]]; then
  echo "ERROR: run this installer as root" >&2
  exit 1
fi

echo "[1/9] Installing required Ubuntu packages"
apt-get update
DEBIAN_FRONTEND=noninteractive apt-get install -y \
  ca-certificates curl iproute2 iptables build-essential tar gzip

if [[ ! -c /dev/net/tun ]]; then
  modprobe tun || true
fi
if [[ ! -c /dev/net/tun ]]; then
  echo "ERROR: /dev/net/tun is unavailable" >&2
  exit 1
fi

install_go() {
  local arch archive expected actual
  arch="$(uname -m)"
  case "$arch" in
    x86_64|amd64)
      archive="go${GO_REQUIRED}.linux-amd64.tar.gz"
      expected="$GO_AMD64_SHA256"
      ;;
    *)
      echo "ERROR: unsupported CPU architecture for bundled Go installer: $arch" >&2
      exit 1
      ;;
  esac

  echo "Installing Go ${GO_REQUIRED} for ${arch}"
  curl --fail --location --retry 3 --connect-timeout 15 \
    "https://go.dev/dl/${archive}" -o "$BUILD_DIR/$archive"
  actual="$(sha256sum "$BUILD_DIR/$archive" | awk '{print $1}')"
  if [[ "$actual" != "$expected" ]]; then
    echo "ERROR: Go archive checksum mismatch" >&2
    echo "Expected: $expected" >&2
    echo "Actual:   $actual" >&2
    exit 1
  fi

  if [[ -d /usr/local/go ]]; then
    mv /usr/local/go "/usr/local/go.backup.${STAMP}"
  fi
  tar -C /usr/local -xzf "$BUILD_DIR/$archive"
  ln -sfn /usr/local/go/bin/go /usr/local/bin/go
  ln -sfn /usr/local/go/bin/gofmt /usr/local/bin/gofmt
  printf '%s\n' 'export PATH="/usr/local/go/bin:$PATH"' >/etc/profile.d/golang.sh
  chmod 644 /etc/profile.d/golang.sh
}

CURRENT_GO=""
if command -v go >/dev/null 2>&1; then
  CURRENT_GO="$(go version 2>/dev/null | awk '{print $3}' || true)"
fi
if [[ "$CURRENT_GO" != "go${GO_REQUIRED}" ]]; then
  install_go
fi
export PATH="/usr/local/go/bin:/usr/local/bin:$PATH"
GO_VERSION="$(go env GOVERSION)"
if [[ "$GO_VERSION" != "go${GO_REQUIRED}" ]]; then
  echo "ERROR: expected go${GO_REQUIRED}, found $GO_VERSION" >&2
  exit 1
fi
echo "Using $GO_VERSION"

echo "[2/9] Checking the VPS network interface"
WAN_IF="$(ip -4 route get 1.1.1.1 2>/dev/null | awk 'NR==1 {for (i=1; i<=NF; i++) if ($i=="dev") {print $(i+1); exit}}')"
if [[ -z "$WAN_IF" ]]; then
  WAN_IF="$(ip -4 route show default | awk 'NR==1 {for (i=1; i<=NF; i++) if ($i=="dev") {print $(i+1); exit}}')"
fi
if [[ -z "$WAN_IF" || "$WAN_IF" == "lo" || ! -e "/sys/class/net/$WAN_IF" ]]; then
  echo "ERROR: could not detect a valid Internet network interface" >&2
  exit 1
fi
WAN_IPV4="$(ip -4 -o addr show dev "$WAN_IF" scope global | awk 'NR==1 {split($4,a,"/"); print a[1]}')"
if [[ -z "$WAN_IPV4" ]]; then
  echo "ERROR: interface $WAN_IF has no global IPv4 address" >&2
  exit 1
fi
echo "Detected WAN interface: $WAN_IF ($WAN_IPV4)"
install -d -m 755 /etc/default
printf 'WAN_IFACE=%s\n' "$WAN_IF" >/etc/default/mnr
chmod 644 /etc/default/mnr

echo "[3/9] Enabling persistent IPv4 forwarding"
install -d -m 755 /etc/sysctl.d
printf '%s\n' 'net.ipv4.ip_forward=1' >/etc/sysctl.d/99-vpn-forward.conf
sysctl -w net.ipv4.ip_forward=1 >/dev/null

echo "[4/9] Verifying required ports"
echo "Port ownership will be checked after stopping an installed older MNR version"

echo "[5/9] Building Mode 6"
install -d -m 700 "$BUILD_DIR/mode6"
cp "$ROOT_DIR/mode6/main.go" "$ROOT_DIR/mode6/go.mod" \
  "$ROOT_DIR/mode6/go.sum" "$ROOT_DIR/mode6/crypto.go" "$BUILD_DIR/mode6/"
(
  cd "$BUILD_DIR/mode6"
  gofmt -w main.go crypto.go
  # Go 1.24 may need to refresh indirect module metadata after adding the
  # encryption source. This runs only inside the disposable build directory.
  go mod tidy
  go mod download
  CGO_ENABLED=0 go build -trimpath -ldflags='-s -w' -o abso .
)

echo "[6/9] Building Mode 7"
install -d -m 700 "$BUILD_DIR/mode7"
cp "$ROOT_DIR/mode7/main.go" "$ROOT_DIR/mode6/crypto.go" "$BUILD_DIR/mode7/"
(
  cd "$BUILD_DIR/mode7"
  gofmt -w main.go crypto.go
  CGO_ENABLED=0 go build -trimpath -ldflags='-s -w' -o stunudp main.go crypto.go
)

echo "[7/9] Installing binaries and preserving existing data"
install -d -m 700 "$MODE6_DIR/backups" "$MODE7_DIR/backups"
if [[ -f "$MODE6_DIR/abso" ]]; then
  cp -a "$MODE6_DIR/abso" "$MODE6_DIR/backups/abso.$STAMP"
fi
if [[ -f "$MODE7_DIR/stunudp" ]]; then
  cp -a "$MODE7_DIR/stunudp" "$MODE7_DIR/backups/stunudp.$STAMP"
fi
install -m 700 "$BUILD_DIR/mode6/abso" "$MODE6_DIR/abso"
install -m 700 "$BUILD_DIR/mode7/stunudp" "$MODE7_DIR/stunudp"
install -d -m 700 /etc/mnr
install -m 600 "$ROOT_DIR/config/server_identity.pem" /etc/mnr/crypto_identity.pem

# Protect the public Mode 6 dashboard and every administrative API on :8080.
# Existing credentials are preserved across reinstalls. For a first install,
# enter the password interactively or pass MNR_PANEL_PASSWORD in the command
# environment. The password itself is never embedded in source or systemd.
PANEL_USER="admin"
PANEL_CREDENTIALS_FILE="/etc/mnr/panel.env"
if [[ -f "$PANEL_CREDENTIALS_FILE" ]]; then
  PANEL_USER="$(sed -n 's/^MNR_PANEL_USER=//p' "$PANEL_CREDENTIALS_FILE" | head -n1)"
  PANEL_PASSWORD_B64="$(sed -n 's/^MNR_PANEL_PASSWORD_B64=//p' "$PANEL_CREDENTIALS_FILE" | head -n1)"
  if [[ -z "$PANEL_USER" || -z "$PANEL_PASSWORD_B64" ]]; then
    echo "ERROR: invalid $PANEL_CREDENTIALS_FILE" >&2
    exit 1
  fi
  PANEL_PASSWORD="$(printf '%s' "$PANEL_PASSWORD_B64" | base64 -d)"
  echo "Preserving existing panel username: $PANEL_USER"
else
  PANEL_PASSWORD="${MNR_PANEL_PASSWORD:-}"
  if [[ -z "$PANEL_PASSWORD" && -t 0 ]]; then
    while [[ ${#PANEL_PASSWORD} -lt 12 ]]; do
      read -r -s -p "Choose panel password for admin (minimum 12 characters): " PANEL_PASSWORD
      echo
      if [[ ${#PANEL_PASSWORD} -lt 12 ]]; then
        echo "Password is too short."
      fi
    done
  fi
  if [[ -z "$PANEL_PASSWORD" ]]; then
    PANEL_RANDOM="$(< /proc/sys/kernel/random/uuid)$(< /proc/sys/kernel/random/uuid)"
    PANEL_RANDOM="${PANEL_RANDOM//-/}"
    PANEL_PASSWORD="${PANEL_RANDOM:0:24}"
    echo "Generated panel password: $PANEL_PASSWORD"
    echo "Save it now; it will not be printed again."
  fi
  PANEL_PASSWORD_B64="$(printf '%s' "$PANEL_PASSWORD" | base64 -w0)"
  printf 'MNR_PANEL_USER=%s\nMNR_PANEL_PASSWORD_B64=%s\n' \
    "$PANEL_USER" "$PANEL_PASSWORD_B64" >"$PANEL_CREDENTIALS_FILE"
  chmod 600 "$PANEL_CREDENTIALS_FILE"
fi

echo "[8/9] Installing and starting systemd services"
systemctl stop stunudp abso 2>/dev/null || true

# Ubuntu's systemd-resolved commonly reserves 127.0.0.53:53. Mode 6 must
# listen on TCP/UDP 53, so disable only the local stub listener while keeping
# systemd-resolved active for normal outbound DNS resolution.
if ss -H -lntup | grep -E ':53[[:space:]]' | grep -q 'systemd-resolve'; then
  echo "Releasing TCP/UDP port 53 from systemd-resolved"
  install -d -m 755 /etc/systemd/resolved.conf.d
  cat >/etc/systemd/resolved.conf.d/99-mnr-disable-stub.conf <<'EOF'
[Resolve]
DNSStubListener=no
EOF

  if [[ ! -e /etc/resolv.conf.mnr-backup && -e /etc/resolv.conf ]]; then
    cp -a /etc/resolv.conf /etc/resolv.conf.mnr-backup
  fi

  systemctl restart systemd-resolved
  for _ in $(seq 1 20); do
    if ! ss -H -lntup | grep -E ':53[[:space:]]' | grep -q 'systemd-resolve'; then
      break
    fi
    sleep 0.25
  done

  if [[ -e /run/systemd/resolve/resolv.conf ]]; then
    ln -sfn /run/systemd/resolve/resolv.conf /etc/resolv.conf
  else
    printf '%s\n' 'nameserver 1.1.1.1' 'nameserver 8.8.8.8' >/etc/resolv.conf
  fi
fi

if ss -H -lntup | awk '{print $5}' | grep -Eq '(^|:)(53)$'; then
  echo "ERROR: port 53 is occupied by a non-MNR process" >&2
  ss -lntup | grep -E ':53([[:space:]]|$)' || true
  exit 1
fi
if ss -H -lunp | awk '{print $5}' | grep -Eq '(^|:)(19302)$'; then
  echo "ERROR: UDP port 19302 is occupied by a non-MNR process" >&2
  ss -lunp | grep -E ':19302([[:space:]]|$)' || true
  exit 1
fi
install -m 644 "$ROOT_DIR/systemd/abso.service" /etc/systemd/system/abso.service
install -m 644 "$ROOT_DIR/systemd/stunudp.service" /etc/systemd/system/stunudp.service
systemctl daemon-reload
systemctl enable --now abso
sleep 2
systemctl is-active --quiet abso
curl -fsS --max-time 4 -u "$PANEL_USER:$PANEL_PASSWORD" \
  http://127.0.0.1:8080/api/clients >/dev/null
systemctl enable --now stunudp
sleep 2
systemctl is-active --quiet stunudp
curl -fsS --max-time 4 http://127.0.0.1:8081/health

echo "[9/9] Installation complete"
systemctl --no-pager --full status abso stunudp | sed -n '1,42p'
ss -lntup | grep -E ':53 |:19302 |:8080|127.0.0.1:8081' || true
echo "Mode 6: TCP/UDP 53, tun100, 10.4.0.0/22"
echo "Mode 7: UDP 19302, tun200, 10.8.0.0/24"
